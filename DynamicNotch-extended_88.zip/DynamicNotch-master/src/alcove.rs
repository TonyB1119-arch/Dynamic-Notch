//! The Alcove look's own notch screens: a home page with the weather on the left and a big
//! clock beside it, and a column of page dots on the right edge. Hovering the dots opens a
//! page switcher laid over the notch; the wheel over them steps through the pages.
//!
//! Everything is drawn with the same primitives as the other looks.

use std::cell::Cell;

use crate::gfx::{Icon, TextStyle};
use crate::modules::{Module, ModuleId};
use crate::ui::{gkey, Ui};
use crate::util::{palette, Color, Rect};

/// Space above, left of, right of and under the page content.
pub const TOP: f32 = 26.0;
pub const LEFT: f32 = 30.0;
pub const RIGHT: f32 = 54.0;
pub const BOTTOM: f32 = 26.0;
/// Height of the home page.
pub const HOME_H: f32 = 140.0;

/// How many dots show at once; the window follows the open page.
const MAX_DOTS: usize = 7;

thread_local! {
    static OPEN: Cell<bool> = const { Cell::new(false) };
}

/// Is the page switcher showing? (the page underneath then ignores the mouse)
pub fn rail_open() -> bool {
    OPEN.with(|o| o.get())
}

fn title_of(modules: &[Box<dyn Module>], id: ModuleId) -> String {
    if id == "home" {
        return "Home".to_string();
    }
    match modules.iter().find(|m| m.id() == id).map(|m| m.title().to_string()) {
        Some(t) if t == "Wi-Fi & Bluetooth" => "Network".to_string(),
        Some(t) if t == "Volume & Brightness" => "Sound".to_string(),
        Some(t) => t,
        None => String::new(),
    }
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------

pub fn home(ui: &mut Ui, r: Rect, _modules: &mut [Box<dyn Module>]) {
    // settings gear, top left
    let gear = Rect::new(r.x - 4.0, r.y - 8.0, 22.0, 22.0);
    let hover = ui.hovered(gear);
    if hover {
        ui.hot = true;
    }
    let a = ui.glide(gkey("alcove-gear", 0), if hover { 1.0 } else { 0.0 });
    ui.p.icon(Icon::Settings, gear, Color::white(0.45 + 0.45 * a));
    if ui.clicked(gear) {
        ui.fx.open_page = Some("settings");
    }

    let brief = crate::modules::weather::brief();
    let unit = if ui.cfg.weather.units == "imperial" { "F" } else { "C" };

    // left: weather
    let left_w = 150.0;
    let wy = r.y + 34.0;
    match &brief {
        Some(b) => {
            b.draw_icon(ui.p, Rect::new(r.x, wy, 40.0, 40.0));
            let temp = TextStyle::new(30.0, Color::white(1.0)).semibold();
            ui.p.text(&format!("{:.0}°{unit}", b.temp), Rect::new(r.x + 50.0, wy - 2.0, left_w - 50.0, 44.0), &temp);
            let mut place = b.place.clone();
            if place.chars().count() > 18 {
                place = place.chars().take(17).collect::<String>() + "…";
            }
            ui.p.text(&place, Rect::new(r.x, wy + 48.0, left_w, 20.0), &TextStyle::new(13.0, palette::TEXT_DIM));
        }
        None => {
            ui.p.icon(Icon::Cloud, Rect::new(r.x, wy, 36.0, 36.0), Color::white(0.3));
            ui.p.text(
                "Weather is off",
                Rect::new(r.x + 46.0, wy, left_w, 36.0),
                &TextStyle::new(13.0, palette::TEXT_FAINT),
            );
        }
    }

    // centre: the time, the date and the sky
    let (h, m, _s, suffix, date) = crate::app::clock_parts();
    let time = format!("{h:02}:{m:02}");
    let big = TextStyle::new(64.0, Color::white(1.0)).weight(700).center();
    let area = Rect::new(r.x + left_w + 10.0, r.y, r.w - left_w - 10.0, r.h);
    let (tw, _) = ui.p.measure(&time, &big);
    let cx = area.cx();
    ui.p.text(&time, Rect::new(cx - tw * 0.5 - 4.0, r.y + 2.0, tw + 8.0, 78.0), &big);
    if !suffix.is_empty() {
        ui.p.text(
            &suffix,
            Rect::new(cx + tw * 0.5 + 6.0, r.y + 30.0, 40.0, 24.0),
            &TextStyle::new(15.0, palette::TEXT_DIM).semibold(),
        );
    }
    let sub = match &brief {
        Some(b) => format!("{date}  ·  {}", b.label),
        None => date,
    };
    ui.p.text(
        &sub,
        Rect::new(area.x, r.y + 86.0, area.w, 24.0),
        &TextStyle::new(15.0, palette::TEXT_DIM).medium().center(),
    );
}

// ---------------------------------------------------------------------------
// Page dots and the page switcher
// ---------------------------------------------------------------------------

pub fn rail(ui: &mut Ui, full: Rect, modules: &[Box<dyn Module>], tabs: &[(ModuleId, Icon, String)], page: ModuleId) {
    if tabs.len() < 2 {
        return;
    }
    let n = tabs.len();
    let cur = tabs.iter().position(|t| t.0 == page).unwrap_or(0);

    // the dots
    let shown = n.min(MAX_DOTS);
    let first = if n <= MAX_DOTS { 0 } else { cur.saturating_sub(shown / 2).min(n - shown) };
    let pitch = 16.0;
    let col_h = pitch * shown as f32;
    let zone = Rect::new(full.right() - 46.0, full.cy() - col_h * 0.5 - 14.0, 46.0, col_h + 28.0);

    let was_open = rail_open();
    let panel = full.inset_xy(18.0, 14.0);
    let over_zone = ui.hovered(zone);
    let over_panel = was_open && ui.hovered(panel);
    let open = over_zone || over_panel;
    OPEN.with(|o| o.set(open));
    let t = ui.glide(gkey("alcove-rail", 0), if open { 1.0 } else { 0.0 });
    if (t - if open { 1.0 } else { 0.0 }).abs() > 0.01 {
        ui.animate();
    }

    // the wheel over the dots steps through the pages
    let wheel = ui.wheel(zone);
    if wheel != 0.0 {
        let next = if wheel < 0.0 { (cur + 1) % n } else { (cur + n - 1) % n };
        ui.fx.open_page = Some(tabs[next].0);
    }

    for k in 0..shown {
        let i = first + k;
        let y = zone.y + 14.0 + pitch * (k as f32 + 0.5);
        let x = full.right() - 22.0;
        let on = ui.glide(gkey("alcove-dot", i), if i == cur { 1.0 } else { 0.0 });
        let edge =
            if n > MAX_DOTS && ((k == 0 && first > 0) || (k + 1 == shown && first + shown < n)) { 0.6 } else { 1.0 };
        let hw = 3.0 * edge;
        let hh = hw + 4.5 * on;
        let c = Color::white(0.28 + 0.68 * on);
        ui.p.fill_rounded(Rect::new(x - hw, y - hh, hw * 2.0, hh * 2.0), hw, c);
    }
    if over_zone {
        ui.hot = true;
    }

    // the switcher: every page as a tile, laid over the notch
    if t < 0.01 {
        return;
    }
    let a0 = ui.p.alpha;
    ui.p.alpha = a0 * t;
    let slide = (1.0 - t) * 14.0;
    let panel = Rect::new(panel.x + slide, panel.y, panel.w, panel.h);
    ui.p.fill_rounded(panel, 28.0, Color::hex(0x0B0B0D).with_a(0.97));
    ui.p.stroke_rounded(panel.inset(0.5), 28.0, 1.0, Color::white(0.08));

    let inner = panel.inset_xy(18.0, 16.0);
    let cols = ((inner.w + 8.0) / 150.0).floor().clamp(2.0, 6.0) as usize;
    let rows = n.div_ceil(cols);
    let gap = 8.0;
    let tw = (inner.w - gap * (cols - 1) as f32) / cols as f32;
    let th = ((inner.h - gap * (rows.saturating_sub(1)) as f32) / rows as f32).clamp(30.0, 46.0);
    let used = th * rows as f32 + gap * rows.saturating_sub(1) as f32;
    let top = inner.y + (inner.h - used).max(0.0) * 0.5;
    let st = TextStyle::new(13.5, Color::white(0.9)).medium();
    for (i, (id, icon, _)) in tabs.iter().enumerate() {
        let (cx_i, cy_i) = (i % cols, i / cols);
        let r = Rect::new(inner.x + cx_i as f32 * (tw + gap), top + cy_i as f32 * (th + gap), tw, th);
        let sel = *id == page;
        let hover = ui.hovered(r);
        if hover {
            ui.hot = true;
        }
        let h = ui.glide(gkey("alcove-tile", i), if hover { 1.0 } else { 0.0 });
        let bg = if sel { Color::white(0.92) } else { Color::white(0.07 + 0.07 * h) };
        ui.p.fill_rounded(r, th * 0.38, bg);
        let fg = if sel { palette::INK } else { Color::white(0.92) };
        ui.p.icon(*icon, Rect::new(r.x + 12.0, r.cy() - 9.0, 18.0, 18.0), fg);
        let title = title_of(modules, id);
        ui.p.push_clip(r);
        ui.p.text(&title, Rect::new(r.x + 38.0, r.y, r.w - 44.0, r.h), &st.color(fg));
        ui.p.pop_clip();
        if ui.clicked(r) && !sel {
            ui.fx.open_page = Some(*id);
        }
    }
    ui.p.alpha = a0;
}
