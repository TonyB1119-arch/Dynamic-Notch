//! Device peeks: a short notice when a USB drive is plugged in or removed
//! and when a display is connected or disconnected. Purely event driven: the
//! shell forwards Windows' device and display messages, nothing is polled.

use std::time::{Duration, Instant};

use super::{Cx, Module, ModuleId, Peek, SystemEvent};
use crate::gfx::Icon;
use crate::util::palette;

const ID: ModuleId = "devices";
/// Windows sends several display messages for one change.
const DISPLAY_GAP: Duration = Duration::from_secs(4);
/// Ignore display changes while the app is still starting up.
const SETTLE: Duration = Duration::from_secs(8);

pub struct Devices {
    born: Instant,
    last_display: Option<Instant>,
}

impl Devices {
    pub fn new() -> Self {
        Self { born: Instant::now(), last_display: None }
    }
}

impl Module for Devices {
    fn id(&self) -> ModuleId {
        ID
    }
    fn title(&self) -> &str {
        "Devices"
    }
    fn icon(&self) -> Icon {
        Icon::Package
    }

    fn on_system(&mut self, ev: &SystemEvent, cx: &mut Cx) {
        let SystemEvent::Command { verb, args } = ev else { return };
        match verb.as_str() {
            "usb" => {
                let drive = args.first().cloned().unwrap_or_default();
                let arrived = args.get(1).is_some_and(|a| a == "in");
                let (title, color) =
                    if arrived { ("Drive connected", palette::BLUE) } else { ("Drive removed", palette::TEXT_DIM) };
                cx.fx.peek(Peek::new(Icon::Folder, color, title, drive).key("devices").duration_ms(3000));
            }
            "display" => {
                let now = cx.now;
                if now.saturating_duration_since(self.born) < SETTLE
                    || self.last_display.is_some_and(|t| now.saturating_duration_since(t) < DISPLAY_GAP)
                {
                    return;
                }
                self.last_display = Some(now);
                cx.fx.peek(
                    Peek::new(Icon::Image, palette::BLUE, "Display changed", "Screen layout was updated")
                        .key("devices")
                        .duration_ms(2500),
                );
            }
            _ => {}
        }
    }
}
