//! Greets you when you unlock the PC: a short peek with "Good morning, Sam"
//! and today's date.
//!
//! The shell registers for session notifications and forwards an `unlocked`
//! command; this module waits a moment (the desktop is still coming back) and
//! then shows the peek. Switch it off in Settings or with `greeting = false`
//! under `[modules]`; set `[greeting] name` to be greeted by another name.

use std::time::{Duration, Instant};

use windows::Win32::System::SystemInformation::GetLocalTime;

use super::{Cx, Module, ModuleId, Peek, SystemEvent};
use crate::gfx::Icon;
use crate::util::Color;

const ID: ModuleId = "greeting";
/// Let the desktop finish appearing before the peek slides out.
const DELAY: Duration = Duration::from_millis(900);
/// Unlock events can repeat (remote sessions, fast user switching).
const MIN_GAP: Duration = Duration::from_secs(10);

pub struct Greeting {
    due: Option<Instant>,
    last: Option<Instant>,
}

impl Greeting {
    pub fn new() -> Self {
        Self { due: None, last: None }
    }
}

impl Module for Greeting {
    fn id(&self) -> ModuleId {
        ID
    }
    fn title(&self) -> &str {
        "Unlock greeting"
    }
    fn icon(&self) -> Icon {
        Icon::Sparkle
    }

    fn stop(&mut self) {
        self.due = None;
    }

    fn on_system(&mut self, ev: &SystemEvent, cx: &mut Cx) {
        if let SystemEvent::Command { verb, .. } = ev {
            if verb == "unlocked" && self.last.is_none_or(|t| t.elapsed() > MIN_GAP) {
                self.due = Some(cx.now + DELAY);
            }
        }
    }

    fn next_tick(&self) -> Option<Instant> {
        self.due
    }

    fn on_tick(&mut self, cx: &mut Cx) {
        if !self.due.is_some_and(|d| cx.now >= d) {
            return;
        }
        self.due = None;
        self.last = Some(cx.now);
        // Default: just the padlock and a green check, nothing to read. Set
        // `[greeting] name` to get "Good morning, Sam" and the date as well.
        let peek = if cx.cfg.greeting.name.trim().is_empty() {
            Peek::new(Icon::Unlock, Color::hex(0x34C759), "", "").duration_ms(2600)
        } else {
            let t = unsafe { GetLocalTime() };
            let title = match display_name(&cx.cfg.greeting.name) {
                Some(n) => format!("{}, {n}", greeting_for_hour(t.wHour)),
                None => greeting_for_hour(t.wHour).to_string(),
            };
            let subtitle = format!("{}, {} {}", weekday(t.wDayOfWeek), month(t.wMonth), t.wDay);
            Peek::new(Icon::Unlock, Color::hex(0x34C759), title, subtitle).duration_ms(4500)
        };
        cx.fx.peek(peek.key("greeting"));
        cx.fx.redraw = true;
    }
}

fn greeting_for_hour(h: u16) -> &'static str {
    match h {
        5..=11 => "Good morning",
        12..=16 => "Good afternoon",
        17..=21 => "Good evening",
        _ => "Good night",
    }
}

/// The configured name, or the Windows user name with a capital first letter.
fn display_name(configured: &str) -> Option<String> {
    let raw = if configured.trim().is_empty() {
        std::env::var("USERNAME").unwrap_or_default()
    } else {
        configured.trim().to_string()
    };
    let raw = raw.trim().to_string();
    let mut chars = raw.chars();
    let first = chars.next()?;
    Some(first.to_uppercase().chain(chars).collect())
}

fn weekday(d: u16) -> &'static str {
    ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][(d % 7) as usize]
}

fn month(m: u16) -> &'static str {
    const M: [&str; 12] = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];
    M[(m.clamp(1, 12) - 1) as usize]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parts_of_day() {
        assert_eq!(greeting_for_hour(8), "Good morning");
        assert_eq!(greeting_for_hour(13), "Good afternoon");
        assert_eq!(greeting_for_hour(19), "Good evening");
        assert_eq!(greeting_for_hour(2), "Good night");
    }

    #[test]
    fn names() {
        assert_eq!(display_name("sam").as_deref(), Some("Sam"));
    }
}
