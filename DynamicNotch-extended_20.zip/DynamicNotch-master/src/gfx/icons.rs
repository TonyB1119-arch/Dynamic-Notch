//! Icon set, drawn entirely as vectors in the style of macOS SF Symbols:
//! thin, evenly weighted strokes with round caps on a 24-unit grid, and
//! filled shapes for the media transport. Crisp at any DPI, and no font or
//! asset ships with the binary.

use super::{q, uq, Painter};
use crate::util::{Color, Rect};

#[allow(dead_code)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Icon {
    // vector
    Play,
    Pause,
    Next,
    Prev,
    Sparkle,
    Check,
    Close,
    Plus,
    Minus,
    Stop,
    // glyphs
    Music,
    Timer,
    Clipboard,
    Download,
    Mic,
    Camera,
    Bell,
    Home,
    Settings,
    Folder,
    Copy,
    Trash,
    Image,
    File,
    Link,
    Refresh,
    Send,
    Info,
    Bolt,
    Globe,
    Keyboard,
    Package,
    Volume,
    Mute,
    Brightness,
    Headphones,
    Bluetooth,
    Mouse,
    Gamepad,
    Phone,
    Pulse,
    Wifi,
    Cloud,
    Lock,
    Edit,
    Chat,
    Control,
    Unlock,
}

pub fn draw(p: &mut Painter, icon: Icon, r: Rect, c: Color) {
    if outline(p, icon, r, c) {
        return;
    }
    let s = r.w.min(r.h);
    let b = r.center_square(s);
    let (x, y) = (b.x, b.y);
    match icon {
        // Vector icons are built at the origin and cached on the GPU per size.
        Icon::Play => {
            let s = uq(q(s));
            p.fill_cached((10, q(s), 0, 0, 0), x, y, c, |pb| {
                let pts = [(s * 0.27, s * 0.16), (s * 0.27, s * 0.84), (s * 0.85, s * 0.50)];
                pb.rounded_poly(&pts, s * 0.09)
            });
        }
        Icon::Pause => {
            let w = s * 0.17;
            let h = s * 0.60;
            let gap = s * 0.15;
            let top = y + (s - h) * 0.5;
            let left = x + (s - (2.0 * w + gap)) * 0.5;
            p.fill_rounded(Rect::new(left, top, w, h), w * 0.32, c);
            p.fill_rounded(Rect::new(left + w + gap, top, w, h), w * 0.32, c);
        }
        Icon::Stop => {
            let q = s * 0.5;
            p.fill_rounded(b.center_square(q), q * 0.18, c);
        }
        Icon::Next | Icon::Prev => {
            let flip = icon == Icon::Prev;
            let s = uq(q(s));
            let kind = if flip { 12 } else { 11 };
            p.fill_cached((kind, q(s), 0, 0, 0), x, y, c, |pb| {
                for (x0, x1) in [(s * 0.07, s * 0.52), (s * 0.46, s * 0.91)] {
                    let (x0, x1) = if flip { (s - x0, s - x1) } else { (x0, x1) };
                    pb.rounded_poly(&[(x0, s * 0.23), (x0, s * 0.77), (x1, s * 0.50)], s * 0.06);
                }
            });
        }
        Icon::Sparkle => {
            let s = uq(q(s));
            p.fill_cached((13, q(s), 0, 0, 0), x, y, c, |pb| {
                for (cx, cy, rad) in [(s * 0.42, s * 0.56, s * 0.40), (s * 0.80, s * 0.20, s * 0.17)] {
                    pb.move_to(cx, cy - rad);
                    pb.quad_to(cx + rad * 0.12, cy - rad * 0.12, cx + rad, cy);
                    pb.quad_to(cx + rad * 0.12, cy + rad * 0.12, cx, cy + rad);
                    pb.quad_to(cx - rad * 0.12, cy + rad * 0.12, cx - rad, cy);
                    pb.quad_to(cx - rad * 0.12, cy - rad * 0.12, cx, cy - rad);
                    pb.close();
                }
            });
        }
        Icon::Check => {
            let w = s * 0.085;
            p.line(x + s * 0.22, y + s * 0.52, x + s * 0.42, y + s * 0.72, w, c);
            p.line(x + s * 0.42, y + s * 0.72, x + s * 0.80, y + s * 0.30, w, c);
        }
        Icon::Close => {
            let w = s * 0.082;
            p.line(x + s * 0.28, y + s * 0.28, x + s * 0.72, y + s * 0.72, w, c);
            p.line(x + s * 0.72, y + s * 0.28, x + s * 0.28, y + s * 0.72, w, c);
        }
        Icon::Plus => {
            let w = s * 0.09;
            p.line(x + s * 0.5, y + s * 0.24, x + s * 0.5, y + s * 0.76, w, c);
            p.line(x + s * 0.24, y + s * 0.5, x + s * 0.76, y + s * 0.5, w, c);
        }
        Icon::Minus => {
            let w = s * 0.09;
            p.line(x + s * 0.24, y + s * 0.5, x + s * 0.76, y + s * 0.5, w, c);
        }
        _ => {}
    }
}

/// Battery glyph drawn as vector so the fill level is exact.
pub fn battery(p: &mut Painter, r: Rect, level: f32, charging: bool, fill: Color) {
    // body occupies ~88% width, cap the rest
    let h = r.h.min(r.w * 0.5);
    let w = h * 2.05;
    let body = Rect::new(r.cx() - w * 0.5, r.cy() - h * 0.5, w * 0.9, h);
    let stroke = (h * 0.09).max(1.0);
    p.stroke_rounded(body.inset(stroke * 0.5), h * 0.3, stroke, Color::white(0.45));
    let cap = Rect::new(body.right() + stroke * 0.6, body.cy() - h * 0.18, w * 0.06, h * 0.36);
    p.fill_rounded(cap, cap.w * 0.5, Color::white(0.45));
    let inner = body.inset(stroke * 2.0);
    // the charge is five ticks, the last lit one partly
    let n = 5usize;
    let gap = (inner.h * 0.2).max(1.0);
    let cw = ((inner.w - gap * (n as f32 - 1.0)) / n as f32).max(1.0);
    let lvl = level.clamp(0.0, 1.0);
    let pos = (lvl * n as f32).max(if lvl > 0.0 { 0.7 } else { 0.0 });
    for i in 0..n {
        let t = (pos - i as f32).clamp(0.0, 1.0);
        let c = Color::white(0.14).lerp(fill, t);
        p.fill_rounded(Rect::new(inner.x + i as f32 * (cw + gap), inner.y, cw, inner.h), cw.min(inner.h) * 0.3, c);
    }
    if charging {
        let bx = body.cx();
        let by = body.cy();
        // a slightly larger dark bolt underneath acts as the outline
        let bolt = |pb: &crate::gfx::PathBuilder, k: f32| {
            pb.move_to(k * 0.15, -k);
            pb.line_to(-k * 0.55, k * 0.12);
            pb.line_to(-k * 0.02, k * 0.12);
            pb.line_to(-k * 0.15, k);
            pb.line_to(k * 0.55, -k * 0.12);
            pb.line_to(k * 0.02, -k * 0.12);
            pb.close();
        };
        let k = uq(q(h * 0.42));
        p.fill_cached((14, q(k), 0, 0, 0), bx, by, Color::black(0.85), |pb| bolt(pb, k * 1.32));
        p.fill_cached((15, q(k), 0, 0, 0), bx, by, Color::white(1.0), |pb| bolt(pb, k));
    }
}

// ---------------------------------------------------------------------------
// Outline icons (SF Symbols look)
// ---------------------------------------------------------------------------

use std::f32::consts::{FRAC_PI_2, FRAC_PI_4, PI};

/// Pen that draws in a 24x24 grid scaled to the target square.
struct Pen<'p, 'g> {
    p: &'p mut Painter<'g>,
    x: f32,
    y: f32,
    u: f32,
    w: f32,
    c: Color,
}

impl Pen<'_, '_> {
    fn ln(&self, x0: f32, y0: f32, x1: f32, y1: f32) {
        let (x, y, u) = (self.x, self.y, self.u);
        self.p.line(x + x0 * u, y + y0 * u, x + x1 * u, y + y1 * u, self.w, self.c);
    }

    /// Connected line segments.
    fn poly(&self, pts: &[(f32, f32)], closed: bool) {
        for pair in pts.windows(2) {
            self.ln(pair[0].0, pair[0].1, pair[1].0, pair[1].1);
        }
        if closed && pts.len() > 2 {
            let (a, b) = (pts[pts.len() - 1], pts[0]);
            self.ln(a.0, a.1, b.0, b.1);
        }
    }

    fn ring(&self, cx: f32, cy: f32, r: f32) {
        self.p.stroke_circle(self.x + cx * self.u, self.y + cy * self.u, r * self.u, self.w, self.c);
    }

    fn dot(&self, cx: f32, cy: f32, r: f32) {
        self.p.fill_circle(self.x + cx * self.u, self.y + cy * self.u, r * self.u, self.c);
    }

    fn rr(&self, x: f32, y: f32, w: f32, h: f32, radius: f32) {
        let r = Rect::new(self.x + x * self.u, self.y + y * self.u, w * self.u, h * self.u);
        self.p.stroke_rounded(r, radius * self.u, self.w, self.c);
    }

    /// Arc around (cx, cy): `start` in radians (0 = 12 o'clock, clockwise).
    fn arc(&self, cx: f32, cy: f32, r: f32, start: f32, sweep: f32) {
        self.p.arc(self.x + cx * self.u, self.y + cy * self.u, r * self.u, start, sweep, self.w, self.c);
    }

    /// Point on a circle, same angle convention as `arc`.
    fn at(cx: f32, cy: f32, r: f32, a: f32) -> (f32, f32) {
        (cx + r * a.sin(), cy - r * a.cos())
    }

    /// `n` short rays around a center (sun, gear teeth).
    fn rays(&self, cx: f32, cy: f32, r0: f32, r1: f32, n: usize) {
        for i in 0..n {
            let a = i as f32 * (2.0 * PI / n as f32);
            let (x0, y0) = Self::at(cx, cy, r0, a);
            let (x1, y1) = Self::at(cx, cy, r1, a);
            self.ln(x0, y0, x1, y1);
        }
    }

    fn speaker(&self) {
        self.poly(&[(3.5, 9.5), (7.5, 9.5), (12.5, 5.2), (12.5, 18.8), (7.5, 14.5), (3.5, 14.5)], true);
    }
}

/// Draw `icon` as an outline. Returns false for the icons that are drawn
/// as filled shapes elsewhere (media transport, sparkle, check, close, plus, minus).
fn outline(p: &mut Painter, icon: Icon, r: Rect, c: Color) -> bool {
    if matches!(
        icon,
        Icon::Play
            | Icon::Pause
            | Icon::Next
            | Icon::Prev
            | Icon::Stop
            | Icon::Sparkle
            | Icon::Check
            | Icon::Close
            | Icon::Plus
            | Icon::Minus
    ) {
        return false;
    }
    let s = r.w.min(r.h);
    let b = r.center_square(s);
    let pen = Pen { p, x: b.x, y: b.y, u: s / 24.0, w: (s * 0.082).max(1.25), c };
    match icon {
        Icon::Music => {
            pen.dot(8.6, 17.6, 3.1);
            pen.ln(11.7, 17.6, 11.7, 4.5);
            pen.poly(&[(11.7, 4.5), (18.5, 7.0), (18.0, 11.5)], false);
        }
        Icon::Timer => {
            pen.ring(12.0, 13.5, 7.6);
            pen.ln(10.0, 3.5, 14.0, 3.5);
            pen.ln(12.0, 3.5, 12.0, 5.9);
            pen.ln(12.0, 13.5, 15.0, 10.5);
            pen.ln(18.2, 7.6, 19.4, 6.4);
        }
        Icon::Clipboard => {
            pen.rr(5.0, 5.0, 14.0, 16.0, 3.0);
            pen.rr(8.8, 3.0, 6.4, 4.4, 2.0);
            pen.ln(8.5, 12.0, 15.5, 12.0);
            pen.ln(8.5, 16.0, 13.0, 16.0);
        }
        Icon::Download => {
            pen.ln(12.0, 4.0, 12.0, 15.0);
            pen.poly(&[(7.5, 10.8), (12.0, 15.2), (16.5, 10.8)], false);
            pen.ln(5.0, 19.8, 19.0, 19.8);
        }
        Icon::Mic => {
            pen.rr(9.0, 3.5, 6.0, 11.0, 3.0);
            pen.arc(12.0, 11.0, 6.6, FRAC_PI_2, PI);
            pen.ln(12.0, 17.6, 12.0, 21.0);
            pen.ln(8.5, 21.0, 15.5, 21.0);
        }
        Icon::Camera => {
            pen.rr(3.0, 7.0, 18.0, 13.0, 3.5);
            pen.poly(&[(8.0, 7.0), (9.4, 4.4), (14.6, 4.4), (16.0, 7.0)], false);
            pen.ring(12.0, 13.5, 3.6);
        }
        Icon::Bell => {
            pen.arc(12.0, 10.0, 6.0, -FRAC_PI_2, PI);
            pen.ln(6.0, 10.0, 5.2, 16.0);
            pen.ln(18.0, 10.0, 18.8, 16.0);
            pen.ln(4.2, 16.6, 19.8, 16.6);
            pen.arc(12.0, 18.6, 2.2, FRAC_PI_2, PI);
            pen.ln(12.0, 3.8, 12.0, 4.0);
        }
        Icon::Home => {
            pen.poly(&[(3.5, 11.6), (12.0, 4.0), (20.5, 11.6)], false);
            pen.ln(6.0, 10.2, 6.0, 19.8);
            pen.ln(18.0, 10.2, 18.0, 19.8);
            pen.ln(6.0, 19.8, 18.0, 19.8);
            pen.poly(&[(10.0, 19.8), (10.0, 14.6), (14.0, 14.6), (14.0, 19.8)], false);
        }
        Icon::Settings => {
            pen.ring(12.0, 12.0, 3.2);
            pen.ring(12.0, 12.0, 7.2);
            pen.rays(12.0, 12.0, 8.2, 9.6, 8);
        }
        Icon::Folder => {
            pen.rr(3.0, 7.0, 18.0, 12.8, 3.0);
            pen.poly(&[(3.2, 10.0), (3.2, 6.8), (4.6, 5.0), (9.0, 5.0), (10.8, 7.0)], false);
        }
        Icon::Copy => {
            pen.rr(9.0, 8.5, 11.0, 12.0, 2.6);
            pen.arc(6.6, 6.2, 2.6, -FRAC_PI_2, FRAC_PI_2);
            pen.ln(6.6, 3.6, 13.0, 3.6);
            pen.arc(13.0, 6.2, 2.6, 0.0, FRAC_PI_2);
            pen.ln(4.0, 6.2, 4.0, 13.6);
            pen.arc(6.6, 13.6, 2.6, PI, FRAC_PI_2);
            pen.ln(6.6, 16.2, 9.0, 16.2);
        }
        Icon::Trash => {
            pen.ln(4.5, 6.6, 19.5, 6.6);
            pen.poly(&[(9.4, 6.6), (9.4, 4.4), (14.6, 4.4), (14.6, 6.6)], false);
            pen.poly(&[(6.4, 9.2), (7.4, 19.2), (16.6, 19.2), (17.6, 9.2)], false);
            pen.ln(10.4, 11.8, 10.4, 16.4);
            pen.ln(13.6, 11.8, 13.6, 16.4);
        }
        Icon::Image => {
            pen.rr(3.5, 4.5, 17.0, 15.0, 3.5);
            pen.dot(9.0, 10.0, 1.5);
            pen.poly(&[(4.4, 18.2), (10.0, 13.0), (13.6, 16.4), (16.2, 14.2), (19.6, 17.6)], false);
        }
        Icon::File => {
            pen.rr(5.0, 3.5, 14.0, 17.0, 3.0);
            pen.ln(8.6, 9.6, 15.4, 9.6);
            pen.ln(8.6, 13.2, 15.4, 13.2);
            pen.ln(8.6, 16.8, 12.6, 16.8);
        }
        Icon::Link => {
            // two chain links on a diagonal
            pen.arc(8.0, 16.0, 3.6, 3.0 * FRAC_PI_4, PI);
            pen.ln(10.55, 18.55, 13.4, 15.7);
            pen.ln(5.45, 13.45, 8.3, 10.6);
            pen.arc(16.0, 8.0, 3.6, 7.0 * FRAC_PI_4, PI);
            pen.ln(13.45, 5.45, 10.6, 8.3);
            pen.ln(18.55, 10.55, 15.7, 13.4);
            pen.ln(10.6, 13.4, 13.4, 10.6);
        }
        Icon::Refresh => {
            pen.arc(12.0, 12.0, 7.2, FRAC_PI_4, 1.5 * PI);
            let (tx, ty) = Pen::at(12.0, 12.0, 7.2, 1.75 * PI);
            pen.ln(tx, ty, tx - 4.0, ty);
            pen.ln(tx, ty, tx, ty + 4.0);
        }
        Icon::Send => {
            pen.poly(&[(3.5, 11.0), (20.5, 3.5), (14.0, 20.5), (11.2, 13.2)], true);
            pen.ln(11.2, 13.2, 20.5, 3.5);
        }
        Icon::Info => {
            pen.ring(12.0, 12.0, 9.0);
            pen.dot(12.0, 7.9, 1.1);
            pen.ln(12.0, 11.2, 12.0, 16.6);
        }
        Icon::Bolt => {
            pen.poly(&[(13.6, 3.0), (6.0, 13.4), (11.6, 13.4), (10.4, 21.0), (18.0, 10.6), (12.4, 10.6)], true);
        }
        Icon::Globe => {
            pen.ring(12.0, 12.0, 9.0);
            pen.rr(7.6, 3.0, 8.8, 18.0, 4.4);
            pen.ln(3.0, 12.0, 21.0, 12.0);
            pen.ln(5.0, 7.6, 19.0, 7.6);
            pen.ln(5.0, 16.4, 19.0, 16.4);
        }
        Icon::Keyboard => {
            pen.rr(2.5, 6.5, 19.0, 11.0, 3.0);
            for x in [7.0, 10.3, 13.7, 17.0] {
                pen.dot(x, 10.4, 0.9);
            }
            pen.ln(8.0, 14.4, 16.0, 14.4);
        }
        Icon::Package => {
            pen.poly(&[(12.0, 3.4), (19.6, 7.6), (12.0, 11.8), (4.4, 7.6)], true);
            pen.ln(4.4, 7.6, 4.4, 16.4);
            pen.ln(4.4, 16.4, 12.0, 20.6);
            pen.ln(12.0, 20.6, 19.6, 16.4);
            pen.ln(19.6, 16.4, 19.6, 7.6);
            pen.ln(12.0, 11.8, 12.0, 20.6);
        }
        Icon::Volume => {
            pen.speaker();
            pen.arc(12.5, 12.0, 4.8, 0.3 * PI, 0.4 * PI);
            pen.arc(12.5, 12.0, 8.2, 0.3 * PI, 0.4 * PI);
        }
        Icon::Mute => {
            pen.speaker();
            pen.ln(16.2, 9.6, 21.0, 14.4);
            pen.ln(21.0, 9.6, 16.2, 14.4);
        }
        Icon::Brightness => {
            pen.ring(12.0, 12.0, 4.2);
            pen.rays(12.0, 12.0, 7.4, 9.8, 8);
        }
        Icon::Headphones => {
            pen.arc(12.0, 13.0, 7.5, -FRAC_PI_2, PI);
            pen.rr(4.5, 13.0, 3.6, 6.6, 1.8);
            pen.rr(15.9, 13.0, 3.6, 6.6, 1.8);
        }
        Icon::Bluetooth => {
            pen.ln(12.0, 3.5, 12.0, 20.5);
            pen.ln(12.0, 3.5, 17.5, 8.0);
            pen.ln(17.5, 8.0, 6.5, 16.6);
            pen.ln(12.0, 20.5, 17.5, 16.0);
            pen.ln(17.5, 16.0, 6.5, 7.4);
        }
        Icon::Mouse => {
            pen.rr(6.5, 3.5, 11.0, 17.0, 5.5);
            pen.ln(12.0, 3.8, 12.0, 9.4);
        }
        Icon::Gamepad => {
            pen.rr(2.5, 7.5, 19.0, 10.0, 5.0);
            pen.ln(7.2, 10.6, 7.2, 14.4);
            pen.ln(5.3, 12.5, 9.1, 12.5);
            pen.dot(15.8, 11.4, 1.0);
            pen.dot(18.2, 13.6, 1.0);
        }
        Icon::Phone => {
            pen.rr(7.0, 2.6, 10.0, 18.8, 2.6);
            pen.ln(10.6, 18.0, 13.4, 18.0);
        }
        Icon::Pulse => {
            pen.poly(&[(2.5, 12.0), (7.0, 12.0), (9.6, 5.8), (13.6, 18.2), (16.2, 12.0), (21.5, 12.0)], false);
        }
        Icon::Wifi => {
            pen.dot(12.0, 19.0, 1.3);
            for rad in [5.2, 9.2, 13.2] {
                pen.arc(12.0, 19.0, rad, -FRAC_PI_4, FRAC_PI_2);
            }
        }
        Icon::Cloud => {
            pen.arc(6.8, 15.0, 3.5, PI, PI);
            pen.arc(11.5, 11.2, 5.2, -0.45 * PI, 1.0 * PI);
            pen.arc(16.8, 15.0, 3.5, 0.0, PI);
            pen.ln(6.8, 18.5, 16.8, 18.5);
        }
        Icon::Lock => {
            pen.rr(5.5, 10.5, 13.0, 10.0, 2.8);
            pen.arc(12.0, 10.5, 4.0, -FRAC_PI_2, PI);
            pen.dot(12.0, 15.4, 1.2);
        }
        Icon::Edit => {
            pen.poly(&[(15.6, 5.4), (18.6, 8.4), (9.4, 17.6), (5.4, 18.6), (6.4, 14.6)], true);
            pen.ln(13.6, 7.4, 16.6, 10.4);
        }
        Icon::Unlock => {
            // padlock with the shackle swung open
            pen.rr(5.0, 11.0, 14.0, 10.0, 3.0);
            pen.dot(12.0, 16.0, 1.3);
            pen.ln(8.0, 11.0, 8.0, 8.4);
            pen.arc(12.0, 8.4, 4.0, -FRAC_PI_2, 0.62 * PI);
        }
        Icon::Control => {
            pen.rr(3.0, 4.5, 18.0, 6.5, 3.25);
            pen.dot(16.0, 7.75, 1.9);
            pen.rr(3.0, 13.0, 18.0, 6.5, 3.25);
            pen.dot(8.0, 16.25, 1.9);
        }
        Icon::Chat => {
            pen.rr(3.0, 4.5, 18.0, 12.5, 5.0);
            pen.poly(&[(8.2, 17.0), (7.2, 20.4), (11.8, 17.0)], false);
        }
        _ => return false,
    }
    true
}
