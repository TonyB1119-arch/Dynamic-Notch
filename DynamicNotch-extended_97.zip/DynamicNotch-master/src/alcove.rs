//! The Alcove look's own notch screens: a home page with the weather on the left and a big
//! clock beside it, and a column of page dots on the right edge. Hovering the dots opens a
//! page switcher laid over the notch; the wheel over them steps through the pages.
//!
//! Everything is drawn with the same primitives as the other looks.

use std::cell::{Cell, RefCell};
use std::collections::HashMap;

use crate::gfx::{Icon, TextStyle};
use crate::modules::{Module, ModuleId};
use crate::ui::{gkey, Ui};
use crate::util::{palette, Color, Rect};

/// Space above, left of, right of and under the page content.
pub const TOP: f32 = 26.0;
pub const LEFT: f32 = 30.0;
pub const RIGHT: f32 = 54.0;
pub const BOTTOM: f32 = 26.0;
/// Height of the home page.
pub const HOME_H: f32 = 142.0;
/// Width of the column of load and battery readings on the right of the home page.
const STATS_W: f32 = 140.0;

/// How many dots show at once; the window follows the open page.
const MAX_DOTS: usize = 7;

thread_local! {
    static OPEN: Cell<bool> = const { Cell::new(false) };
}

/// Is the page switcher showing? (the page underneath then ignores the mouse)
pub fn rail_open() -> bool {
    OPEN.with(|o| o.get())
}

fn title_of(modules: &[Box<dyn Module>], id: ModuleId) -> String {
    if id == "home" {
        return "Home".to_string();
    }
    match modules.iter().find(|m| m.id() == id).map(|m| m.title().to_string()) {
        Some(t) if t == "Wi-Fi & Bluetooth" => "Network".to_string(),
        Some(t) if t == "Volume & Brightness" => "Sound".to_string(),
        Some(t) => t,
        None => String::new(),
    }
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------

pub fn home(ui: &mut Ui, r: Rect, modules: &mut [Box<dyn Module>]) {
    // settings gear, top left
    let gear = Rect::new(r.x - 4.0, r.y - 8.0, 22.0, 22.0);
    let hover = ui.hovered(gear);
    if hover {
        ui.hot = true;
    }
    let a = ui.glide(gkey("alcove-gear", 0), if hover { 1.0 } else { 0.0 });
    ui.p.icon(Icon::Settings, gear, Color::white(0.45 + 0.45 * a));
    if ui.clicked(gear) {
        ui.fx.open_page = Some("settings");
    }

    side_stats(ui, r, modules);

    let brief = crate::modules::weather::brief();
    let unit = if ui.cfg.weather.units == "imperial" { "F" } else { "C" };

    // left: weather
    let left_w = 150.0;
    let wy = r.cy() - 35.0;
    match &brief {
        Some(b) => {
            b.draw_icon(ui.p, Rect::new(r.x, wy, 40.0, 40.0));
            let temp = TextStyle::new(30.0, Color::white(1.0)).semibold();
            ui.p.text(&format!("{:.0}°{unit}", b.temp), Rect::new(r.x + 50.0, wy - 2.0, left_w - 50.0, 44.0), &temp);
            let mut place = b.place.clone();
            if place.chars().count() > 18 {
                place = place.chars().take(17).collect::<String>() + "…";
            }
            ui.p.text(&place, Rect::new(r.x, wy + 48.0, left_w, 20.0), &TextStyle::new(13.0, palette::TEXT_DIM));
        }
        None => {
            ui.p.icon(Icon::Cloud, Rect::new(r.x, wy, 36.0, 36.0), Color::white(0.3));
            ui.p.text(
                "Weather is off",
                Rect::new(r.x + 46.0, wy, left_w, 36.0),
                &TextStyle::new(13.0, palette::TEXT_FAINT),
            );
        }
    }

    // centre: the time, the date and the sky
    let (h, m, _s, suffix, date) = crate::app::clock_parts();
    let time = format!("{h:02}:{m:02}");
    let big = TextStyle::new(58.0, Color::white(1.0)).weight(700).center();
    // centred on the notch itself, not on the content box (which leaves room for the dots)
    let cx = r.cx() + (RIGHT - LEFT) * 0.5;
    let area = Rect::new(cx - 190.0, r.y, 380.0, r.h);
    let (tw, _) = ui.p.measure(&time, &big);
    ui.p.text(&time, Rect::new(cx - tw * 0.5 - 4.0, r.y + 16.0, tw + 8.0, 72.0), &big);
    if !suffix.is_empty() {
        ui.p.text(
            &suffix,
            Rect::new(cx + tw * 0.5 + 4.0, r.y + 40.0, 40.0, 24.0),
            &TextStyle::new(15.0, palette::TEXT_DIM).semibold(),
        );
    }
    let sub = match &brief {
        Some(b) => format!("{date}  ·  {}", b.label),
        None => date,
    };
    ui.p.text(
        &sub,
        Rect::new(area.x, r.y + 98.0, area.w, 24.0),
        &TextStyle::new(15.0, palette::TEXT_DIM).medium().center(),
    );
}

// ---------------------------------------------------------------------------
// Page dots and the page switcher
// ---------------------------------------------------------------------------

pub fn rail(ui: &mut Ui, full: Rect, modules: &[Box<dyn Module>], tabs: &[(ModuleId, Icon, String)], page: ModuleId) {
    if tabs.len() < 2 {
        return;
    }
    let n = tabs.len();
    let cur = tabs.iter().position(|t| t.0 == page).unwrap_or(0);

    // the dots
    let shown = n.min(MAX_DOTS);
    let first = if n <= MAX_DOTS { 0 } else { cur.saturating_sub(shown / 2).min(n - shown) };
    let pitch = 16.0;
    let col_h = pitch * shown as f32;
    let zone = Rect::new(full.right() - 46.0, full.cy() - col_h * 0.5 - 14.0, 46.0, col_h + 28.0);

    let was_open = rail_open();
    let panel = full.inset_xy(18.0, 14.0);
    let over_zone = ui.hovered(zone);
    let over_panel = was_open && ui.hovered(panel);
    let open = over_zone || over_panel;
    OPEN.with(|o| o.set(open));
    let t = ui.glide(gkey("alcove-rail", 0), if open { 1.0 } else { 0.0 });
    if (t - if open { 1.0 } else { 0.0 }).abs() > 0.01 {
        ui.animate();
    }

    for k in 0..shown {
        let i = first + k;
        let y = zone.y + 14.0 + pitch * (k as f32 + 0.5);
        let x = full.right() - 22.0;
        let on = ui.glide(gkey("alcove-dot", i), if i == cur { 1.0 } else { 0.0 });
        let edge =
            if n > MAX_DOTS && ((k == 0 && first > 0) || (k + 1 == shown && first + shown < n)) { 0.6 } else { 1.0 };
        let hw = 3.0 * edge;
        let hh = hw + 4.5 * on;
        let c = Color::white(0.28 + 0.68 * on);
        ui.p.fill_rounded(Rect::new(x - hw, y - hh, hw * 2.0, hh * 2.0), hw, c);
    }
    if over_zone {
        ui.hot = true;
    }

    // the switcher: every page as a tile, laid over the notch
    if t < 0.01 {
        return;
    }
    let a0 = ui.p.alpha;
    ui.p.alpha = a0 * t;
    let slide = (1.0 - t) * 16.0;
    let panel = Rect::new(panel.x, panel.y + slide, panel.w, panel.h);
    ui.p.fill_rounded(panel, 28.0, Color::hex(0x0B0B0D).with_a(0.97));
    ui.p.stroke_rounded(panel.inset(0.5), 28.0, 1.0, Color::white(0.08));

    let inner = panel.inset_xy(18.0, 16.0);
    let cols = ((inner.w + 8.0) / 150.0).floor().clamp(2.0, 6.0) as usize;
    let rows = n.div_ceil(cols);
    let gap = 8.0;
    let tw = (inner.w - gap * (cols - 1) as f32) / cols as f32;
    let th = ((inner.h - gap * (rows.saturating_sub(1)) as f32) / rows as f32).clamp(30.0, 46.0);
    let used = th * rows as f32 + gap * rows.saturating_sub(1) as f32;
    let top = inner.y + (inner.h - used).max(0.0) * 0.5;
    let st = TextStyle::new(13.5, Color::white(0.9)).medium();
    for (i, (id, icon, _)) in tabs.iter().enumerate() {
        let (cx_i, cy_i) = (i % cols, i / cols);
        let r = Rect::new(inner.x + cx_i as f32 * (tw + gap), top + cy_i as f32 * (th + gap), tw, th);
        let sel = *id == page;
        let hover = ui.hovered(r);
        if hover {
            ui.hot = true;
        }
        let h = ui.glide(gkey("alcove-tile", i), if hover { 1.0 } else { 0.0 });
        let bg = if sel { Color::white(0.92) } else { Color::white(0.07 + 0.07 * h) };
        ui.p.fill_rounded(r, th * 0.38, bg);
        let fg = if sel { palette::INK } else { Color::white(0.92) };
        ui.p.icon(*icon, Rect::new(r.x + 12.0, r.cy() - 9.0, 18.0, 18.0), fg);
        let title = title_of(modules, id);
        ui.p.push_clip(r);
        ui.p.text(&title, Rect::new(r.x + 38.0, r.y, r.w - 44.0, r.h), &st.color(fg));
        ui.p.pop_clip();
        if ui.clicked(r) && !sel {
            ui.fx.open_page = Some(*id);
        }
    }
    ui.p.alpha = a0;
}

/// Processor, memory and battery as a column on the right of the home page: each a small
/// label with its value and a thin capsule gauge.
fn side_stats(ui: &mut Ui, r: Rect, modules: &[Box<dyn Module>]) {
    let x = r.right() - STATS_W;
    let pitch = 30.0;
    let mut y = r.cy() - pitch * 1.5 + 4.0;
    let label = TextStyle::new(14.0, palette::TEXT_DIM).medium();
    let value = TextStyle::new(17.0, Color::white(1.0)).semibold().right();
    let mut inds = Vec::new();
    for m in modules.iter().filter(|m| m.id() == "battery") {
        m.indicators(&mut inds);
    }
    let battery = inds.iter().find_map(|i| i.battery);
    let rows = [
        ("Processor", crate::modules::stats::cpu_percent().map_or("--".to_string(), |v| format!("{v}%")), false),
        ("Memory", crate::modules::stats::ram_percent().map_or("--".to_string(), |v| format!("{v}%")), false),
        match battery {
            Some((level, charging)) => (
                if charging { "Charging" } else { "Battery" },
                format!("{:.0}%", level * 100.0),
                level < 0.2 && !charging,
            ),
            None => ("Battery", "AC".to_string(), false),
        },
    ];
    for (name, txt, warn) in rows {
        ui.p.text(name, Rect::new(x, y, STATS_W - 54.0, 24.0), &label);
        let mut v = value;
        if warn {
            v.color = palette::RED;
        }
        ui.p.text(&txt, Rect::new(x + STATS_W - 60.0, y, 60.0, 24.0), &v);
        y += pitch;
    }
}

/// A battery in the Alcove style: a rounded capsule that fills with the charge, a small
/// cap on the right and a bolt while charging.
pub fn battery_glyph(ui: &mut Ui, r: Rect, level: f32, charging: bool) {
    let body = Rect::new(r.x, r.y, r.w - 4.0, r.h);
    let col = crate::app::battery_color(level, charging);
    ui.p.fill_rounded(body, body.h * 0.5, Color::white(0.16));
    let inner = body.inset(2.5);
    let f = level.clamp(0.0, 1.0);
    ui.p.fill_rounded(Rect::new(inner.x, inner.y, (inner.w * f).max(inner.h), inner.h), inner.h * 0.5, col);
    ui.p.fill_rounded(Rect::new(body.right() + 1.5, r.cy() - 3.0, 2.5, 6.0), 1.25, Color::white(0.35));
    if charging {
        ui.p.icon(Icon::Bolt, Rect::centered(body.cx(), body.cy(), body.h * 0.8, body.h * 0.8), Color::black(0.78));
    }
}

/// Four rising bars for a Wi-Fi signal strength (0..=4).
pub fn signal_bars(ui: &mut Ui, r: Rect, bars: u8, color: Color) {
    let w = r.w / 7.0;
    for k in 0..4u8 {
        let h = r.h * (0.34 + 0.22 * k as f32);
        let x = r.x + k as f32 * w * 1.7;
        let on = k < bars;
        ui.p.fill_rounded(Rect::new(x, r.bottom() - h, w, h), w * 0.5, if on { color } else { Color::white(0.18) });
    }
}

/// The strip at the top of the network pages: a round icon, what is going on, a refresh
/// button and the on/off switch. Returns (refresh pressed, switch pressed).
#[allow(clippy::too_many_arguments)]
pub fn status_tile(
    ui: &mut Ui,
    r: Rect,
    icon: Icon,
    tint: Color,
    text: &str,
    text_color: Color,
    on: Option<bool>,
    spinning: bool,
) -> (bool, bool) {
    tile(ui, r, r.h * 0.5, false);
    let d = r.h - 14.0;
    let c = Rect::new(r.x + 7.0, r.y + 7.0, d, d);
    ui.p.icon(icon, c.inset(d * 0.2), tint);
    let mut right = r.right() - 12.0;
    let mut toggled = false;
    if let Some(v) = on {
        let sw = Rect::new(right - 44.0, r.y, 44.0, r.h);
        toggled = crate::modules::widgets::switch(ui, sw, v, tint);
        right = sw.x - 8.0;
    }
    if spinning {
        ui.animate();
    }
    let rb = Rect::new(right - 30.0, r.cy() - 15.0, 30.0, 30.0);
    let refresh = round_button(ui, rb, Icon::Refresh, false);
    ui.p.text(
        text,
        Rect::new(c.right() + 12.0, r.y, (rb.x - c.right() - 20.0).max(0.0), r.h),
        &TextStyle::new(15.0, text_color).semibold(),
    );
    (refresh, toggled)
}

// ---------------------------------------------------------------------------
// Notices (peeks)
// ---------------------------------------------------------------------------

/// Notices that carry a message (a copied text, a notification) are taller: they get a
/// second row with the text in its own soft box.
pub fn peek_tall(pk: &crate::modules::Peek) -> bool {
    if pk.is_hud() || pk.is_compact() || pk.scan {
        return false;
    }
    pk.key == Some("clipboard") || (pk.key.is_none() && pk.subtitle.chars().count() > 34)
}

/// A small rounded label.
fn tag(ui: &mut Ui, right: f32, cy: f32, text: &str, color: Color) -> f32 {
    let st = TextStyle::new(13.0, color).semibold();
    let (w, _) = ui.p.measure(text, &st);
    let r = Rect::new(right - w - 24.0, cy - 14.0, w + 24.0, 28.0);
    ui.p.fill_rounded(r, 14.0, color.with_a(0.18));
    ui.p.text(text, Rect::new(r.x + 12.0, r.y, w + 6.0, r.h), &st);
    r.x
}

/// What a notice looks like: a coloured rounded tile with the icon, the title and a line
/// under it, and on the right whatever belongs to it (battery, a tag, a ring). Notices with
/// a message put it in a soft box below.
pub fn peek_content(ui: &mut Ui, inner: Rect, pk: &crate::modules::Peek) {
    use crate::modules::Trailing;
    let tall = peek_tall(pk);
    let ts = 46.0;
    let top_cy = if tall { inner.y + ts * 0.5 + 2.0 } else { inner.cy() };
    let tile_r = Rect::centered(inner.x + ts * 0.5, top_cy, ts, ts);
    match &pk.image {
        Some(img) => ui.p.image(img, tile_r, 15.0, 1.0),
        None => {
            // just the icon, in the notice's colour, on the plain black
            ui.p.icon(pk.icon, tile_r.inset(5.0), pk.accent.lerp(Color::white(1.0), 0.15));
        }
    }

    // right side
    let mut right = inner.right();
    match &pk.trailing {
        Trailing::Battery { level, charging } => {
            let t = format!("{:.0}%", level * 100.0);
            let st = TextStyle::new(17.0, Color::white(1.0)).semibold().right();
            let (w, _) = ui.p.measure(&t, &st);
            ui.p.text(&t, Rect::new(right - w - 4.0, top_cy - 14.0, w + 4.0, 28.0), &st);
            right -= w + 14.0;
            battery_glyph(ui, Rect::new(right - 38.0, top_cy - 9.0, 38.0, 18.0), *level, *charging);
            right -= 38.0 + 10.0;
        }
        Trailing::Text(s, c) => right = tag(ui, right, top_cy, s, *c) - 10.0,
        Trailing::Ring(f, c) => {
            ui.ring(right - 17.0, top_cy, 34.0, 4.0, *f, *c);
            right -= 44.0;
        }
        _ => {}
    }
    if pk.key == Some("devices") && !pk.subtitle.is_empty() {
        right = tag(ui, right, top_cy, &pk.subtitle, pk.accent) - 10.0;
    }

    let tx = tile_r.right() + 14.0;
    let tw = (right - tx).max(20.0);
    let title_st = TextStyle::new(16.0, Color::white(1.0)).semibold();
    let sub_st = TextStyle::new(13.0, palette::TEXT_DIM);
    let sub_here = !tall && !pk.subtitle.is_empty() && pk.key != Some("devices");
    if sub_here {
        ui.p.text(&pk.title, Rect::new(tx, top_cy - 22.0, tw, 22.0), &title_st);
        ui.p.text(&pk.subtitle, Rect::new(tx, top_cy + 1.0, tw, 20.0), &sub_st);
    } else {
        ui.p.text(&pk.title, Rect::new(tx, top_cy - 12.0, tw, 24.0), &title_st);
    }
    if tall && !pk.subtitle.is_empty() {
        let b =
            Rect::new(inner.x, tile_r.bottom() + 10.0, inner.w, (inner.bottom() - tile_r.bottom() - 10.0).max(24.0));
        ui.p.fill_rounded(b, 18.0, Color::white(0.09));
        ui.p.push_clip(b);
        ui.p.text(
            &pk.subtitle,
            Rect::new(b.x + 14.0, b.y + 6.0, b.w - 28.0, b.h - 12.0),
            &TextStyle::new(13.5, Color::white(0.88)).wrap().top(),
        );
        ui.p.pop_clip();
    }
}

// ---------------------------------------------------------------------------
// Building blocks for the Alcove pages
// ---------------------------------------------------------------------------

thread_local! {
    static SCROLL: RefCell<HashMap<u64, f32>> = RefCell::new(HashMap::new());
}

/// A soft rounded tile.
pub fn tile(ui: &mut Ui, r: Rect, radius: f32, hover: bool) {
    ui.p.fill_rounded(r, radius, Color::white(if hover { 0.12 } else { 0.07 }));
}

/// A page title: a small round icon, the name and a dim note beside it.
pub fn title(ui: &mut Ui, r: Rect, icon: Icon, tint: Color, name: &str, note: &str) {
    let d = r.h.min(30.0);
    let c = Rect::new(r.x, r.cy() - d * 0.5, d, d);
    ui.p.icon(icon, c.inset(d * 0.2), tint);
    let st = TextStyle::new(16.0, Color::white(1.0)).semibold();
    let (w, _) = ui.p.measure(name, &st);
    ui.p.text(name, Rect::new(c.right() + 10.0, r.y, w + 4.0, r.h), &st);
    if !note.is_empty() {
        ui.p.text(
            note,
            Rect::new(c.right() + 10.0 + w + 10.0, r.y, 220.0, r.h),
            &TextStyle::new(13.0, palette::TEXT_FAINT).medium(),
        );
    }
}

/// How wide a chip with this label is.
pub fn chip_w(ui: &mut Ui, label: &str, icon: Option<Icon>) -> f32 {
    let (w, _) = ui.p.measure(label, &TextStyle::new(12.5, Color::white(1.0)).semibold());
    w + 26.0 + if icon.is_some() { 20.0 } else { 0.0 }
}

/// A capsule button. `on` makes it white (the chosen one).
pub fn chip(ui: &mut Ui, r: Rect, label: &str, icon: Option<Icon>, on: bool) -> bool {
    let hover = ui.hovered(r);
    if hover {
        ui.hot = true;
    }
    let bg = if on { Color::white(0.94) } else { Color::white(if hover { 0.17 } else { 0.10 }) };
    ui.p.fill_rounded(r, r.h * 0.5, bg);
    let fg = if on { palette::INK } else { Color::white(0.92) };
    let mut x = r.x + 13.0;
    if let Some(i) = icon {
        ui.p.icon(i, Rect::new(x, r.cy() - 7.0, 14.0, 14.0), fg);
        x += 20.0;
    }
    ui.p.text(label, Rect::new(x, r.y, (r.right() - x).max(0.0), r.h), &TextStyle::new(12.5, fg).semibold());
    ui.clicked(r)
}

/// A round icon button.
pub fn round_button(ui: &mut Ui, r: Rect, icon: Icon, filled: bool) -> bool {
    let hover = ui.hovered(r);
    if hover {
        ui.hot = true;
    }
    let bg = if filled {
        Color::white(if hover { 1.0 } else { 0.94 })
    } else {
        Color::white(if hover { 0.18 } else { 0.10 })
    };
    ui.p.fill_circle(r.cx(), r.cy(), r.w.min(r.h) * 0.5, bg);
    let fg = if filled { palette::INK } else { Color::white(0.92) };
    ui.p.icon(icon, r.center_square(r.w.min(r.h) * 0.5), fg);
    ui.clicked(r)
}

/// A thin capsule gauge.
pub fn meter(ui: &mut Ui, r: Rect, frac: f32, color: Color) {
    ui.p.fill_rounded(r, r.h * 0.5, Color::white(0.14));
    let f = frac.clamp(0.0, 1.0);
    if f > 0.0 {
        ui.p.fill_rounded(Rect::new(r.x, r.y, (r.w * f).max(r.h), r.h), r.h * 0.5, color);
    }
}

/// Sideways scrolling for a row of cards: the wheel over `area` moves it (only when there is
/// something to scroll, so the wheel otherwise still turns the page). Returns the offset.
pub fn scroll_x(ui: &mut Ui, area: Rect, content_w: f32, tag: &str) -> f32 {
    let key = gkey(tag, 0);
    let max = (content_w - area.w).max(0.0);
    let mut target = SCROLL.with(|s| s.borrow().get(&key).copied().unwrap_or(0.0)).clamp(0.0, max);
    if max > 0.0 {
        let wheel = ui.wheel(area);
        if wheel != 0.0 {
            target = (target - wheel * 100.0).clamp(0.0, max);
        }
    }
    SCROLL.with(|s| s.borrow_mut().insert(key, target));
    let shown = ui.glide(key, target);
    if (shown - target).abs() > 0.3 {
        ui.animate();
    }
    shown
}

/// A calm empty state: an icon in a round tile and one line.
pub fn empty(ui: &mut Ui, r: Rect, icon: Icon, msg: &str) {
    tile(ui, r, 26.0, false);
    ui.p.icon(icon, Rect::centered(r.cx(), r.cy() - 14.0, 26.0, 26.0), Color::white(0.4));
    ui.p.text(
        msg,
        Rect::new(r.x + 12.0, r.cy() + 4.0, r.w - 24.0, 22.0),
        &TextStyle::new(13.0, palette::TEXT_FAINT).center(),
    );
}

/// How big the unlock greeting's stage is: wide enough for the name, tall enough for two lines.
pub fn hello_stage(name: &str) -> (f32, f32) {
    if name.is_empty() {
        (230.0, 112.0)
    } else {
        ((70.0 + name.chars().count() as f32 * 22.0).clamp(250.0, 440.0), 158.0)
    }
}
