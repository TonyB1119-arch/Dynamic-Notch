//! Tiny immediate-mode UI layer on top of `Painter`.
//!
//! Modules describe their UI every frame; interaction is resolved against
//! the input snapshot (hover position, press and click positions).

use std::cell::RefCell;
use std::collections::HashMap;
use std::hash::{Hash, Hasher};
use std::time::Instant;

use crate::bus::Bus;
use crate::config::Config;
use crate::gfx::{Icon, ImageData, Painter, TextStyle};
use crate::modules::Effects;
use crate::util::{palette, Color, Rect};

#[derive(Default, Clone, Debug)]
pub struct Input {
    /// Cursor position (logical, window-relative) when over the notch.
    pub mouse: Option<(f32, f32)>,
    /// Press position while the left button is held.
    pub down: Option<(f32, f32)>,
    /// Completed click this frame: (press, release).
    pub click: Option<((f32, f32), (f32, f32))>,
    pub right_click: Option<(f32, f32)>,
    /// Wheel notches this frame (positive = up).
    pub wheel: f32,
}

#[allow(dead_code)] // fields are for modules to use
pub struct Ui<'p, 'a> {
    pub p: &'p mut Painter<'a>,
    pub input: &'p Input,
    pub fx: &'p mut Effects,
    pub cfg: &'p Config,
    pub bus: &'p Bus,
    pub now: Instant,
    /// Current accent color (album art driven or configured).
    pub accent: Color,
    /// Set when the cursor is over something interactive.
    pub hot: bool,
    /// Interaction is disabled while content is fading (prevents misclicks).
    pub interactive: bool,
}

thread_local! {
    /// Values that are gliding towards a target (see `Ui::glide`): key → (shown, last touched).
    static GLIDE: RefCell<HashMap<u64, (f32, Instant)>> = RefCell::new(HashMap::new());
}

/// How quickly gauges and numbers settle on a new value (seconds).
const GLIDE_TAU: f32 = 0.16;

/// Stable key for a value that should glide, e.g. `gkey("cpu", 0)`.
pub fn gkey(tag: &str, i: usize) -> u64 {
    let mut h = std::collections::hash_map::DefaultHasher::new();
    tag.hash(&mut h);
    i.hash(&mut h);
    h.finish()
}

pub fn rect_key(r: Rect, tag: &str) -> u64 {
    let mut h = std::collections::hash_map::DefaultHasher::new();
    tag.hash(&mut h);
    (r.x.round() as i32, r.y.round() as i32, r.w.round() as i32).hash(&mut h);
    h.finish()
}

/// Every lit tick in the app is this blue (the callers' colours only carry opacity).
fn themed(c: Color) -> Color {
    palette::BLUE.with_a(c.a)
}

/// Leading edge of a gauge: a lighter blue.
const TICK_LEAD: Color = Color::hex(0x8CC8FF);

/// Colour of a tick that is not lit.
const TICK_DIM: Color = Color::white(0.16);

/// Layout of a tick row: (tick count, distance between ticks, tick width).
fn tick_geom(w: f32) -> (usize, f32, f32) {
    let n = ((w / 4.6).round() as usize).max(2);
    let step = w / n as f32;
    (n, step, (step * 0.56).max(1.4))
}

/// Layout of a tick ring: (outer radius, tick length, tick width, tick count).
fn ring_geom(diameter: f32, stroke: f32) -> (f32, f32, f32, usize) {
    let outer = diameter * 0.5;
    let len = (stroke * 1.7).clamp(3.5, 12.0);
    let tw = (stroke * 0.42).clamp(1.5, 3.0);
    let n = ((std::f32::consts::TAU * outer) / (tw * 2.1)).round().clamp(18.0, 72.0) as usize;
    (outer, len, tw, n)
}

#[derive(Clone, Copy)]
pub struct ButtonStyle {
    pub fg: Color,
    pub bg: Color,
    pub hover_bg: Color,
    pub radius: f32,
    pub icon_scale: f32,
}

impl Default for ButtonStyle {
    fn default() -> Self {
        Self { fg: palette::TEXT, bg: Color::white(0.0), hover_bg: Color::white(0.12), radius: 999.0, icon_scale: 0.62 }
    }
}

#[allow(dead_code)]
impl ButtonStyle {
    /// White capsule with dark text: the "active" / primary look.
    pub fn inverted() -> Self {
        Self { fg: palette::INK, bg: Color::white(0.95), hover_bg: Color::white(1.0), ..Default::default() }
    }
    pub fn filled(bg: Color) -> Self {
        Self { bg, hover_bg: bg.lerp(Color::white(1.0), 0.15).with_a(bg.a.max(0.2)), ..Default::default() }
    }
    pub fn fg(mut self, c: Color) -> Self {
        self.fg = c;
        self
    }
    pub fn scale(mut self, s: f32) -> Self {
        self.icon_scale = s;
        self
    }
    pub fn radius(mut self, r: f32) -> Self {
        self.radius = r;
        self
    }
}

#[allow(dead_code)]
impl<'p, 'a> Ui<'p, 'a> {
    pub fn hovered(&self, r: Rect) -> bool {
        self.interactive && self.input.mouse.is_some_and(|(x, y)| r.contains(x, y))
    }

    pub fn pressed(&self, r: Rect) -> bool {
        self.interactive
            && self.input.down.is_some_and(|(x, y)| r.contains(x, y))
            && self.input.mouse.is_some_and(|(x, y)| r.contains(x, y))
    }

    pub fn clicked(&mut self, r: Rect) -> bool {
        if !self.interactive {
            return false;
        }
        let hit = self.input.click.is_some_and(|((px, py), (ux, uy))| r.contains(px, py) && r.contains(ux, uy));
        if hit {
            self.fx.redraw = true;
        }
        hit
    }

    /// Click position inside `r` as a 0..1 fraction of its width.
    pub fn clicked_at(&mut self, r: Rect) -> Option<f32> {
        if self.clicked(r) {
            self.input.click.map(|(_, (ux, _))| ((ux - r.x) / r.w).clamp(0.0, 1.0))
        } else {
            None
        }
    }

    pub fn right_clicked(&self, r: Rect) -> bool {
        self.interactive && self.input.right_click.is_some_and(|(x, y)| r.contains(x, y))
    }

    pub fn wheel(&self, r: Rect) -> f32 {
        if self.hovered(r) {
            self.input.wheel
        } else {
            0.0
        }
    }

    pub fn animate(&mut self) {
        self.fx.animate = true;
    }

    // -- widgets --------------------------------------------------------------

    /// Round icon button. Returns true when clicked.
    pub fn icon_button(&mut self, r: Rect, icon: Icon, style: ButtonStyle) -> bool {
        let hover = self.hovered(r);
        let pressed = self.pressed(r);
        if hover {
            self.hot = true;
        }
        let bg = if hover { style.hover_bg } else { style.bg };
        let rr = if pressed { r.inset(r.w * 0.04) } else { r };
        self.p.fill_rounded(rr, style.radius, bg);
        let s = r.w.min(r.h) * style.icon_scale * if pressed { 0.92 } else { 1.0 };
        self.p.icon(icon, r.center_square(s), style.fg);
        self.clicked(r)
    }

    /// Capsule button with a text label (and optional leading icon).
    pub fn pill_button(&mut self, r: Rect, label: &str, icon: Option<Icon>, style: ButtonStyle) -> bool {
        let hover = self.hovered(r);
        let pressed = self.pressed(r);
        if hover {
            self.hot = true;
        }
        let bg = if hover { style.hover_bg } else { style.bg };
        let rr = if pressed { r.inset(1.0) } else { r };
        self.p.fill_rounded(rr, style.radius.min(r.h * 0.5), bg);
        let ts = TextStyle::new((r.h * 0.42).clamp(10.0, 15.0), style.fg).medium().center();
        match icon {
            Some(ic) => {
                let (tw, _) = self.p.measure(label, &ts);
                let is = r.h * 0.5;
                let total = is + 6.0 + tw;
                let x = r.cx() - total * 0.5;
                self.p.icon(ic, Rect::new(x, r.cy() - is * 0.5, is, is), style.fg);
                let tr = Rect::new(x + is + 6.0, r.y, tw + 2.0, r.h);
                self.p.text(label, tr, &TextStyle { align: crate::gfx::Align::Start, ..ts });
            }
            None => self.p.text(label, r, &ts),
        }
        self.clicked(r)
    }

    /// Eases a value towards `target` instead of jumping: call it every frame
    /// with the same key and show the result. Keeps frames coming until it has
    /// arrived, then costs nothing.
    pub fn glide(&mut self, key: u64, target: f32) -> f32 {
        let now = self.now;
        let (v, moving) = GLIDE.with(|m| {
            let mut m = m.borrow_mut();
            if m.len() > 512 {
                m.retain(|_, e| now.saturating_duration_since(e.1).as_secs() < 10);
            }
            let e = m.entry(key).or_insert((target, now));
            // a long gap (idle) still starts the glide gently instead of snapping
            let dt = now.saturating_duration_since(e.1).as_secs_f32().min(1.0 / 30.0);
            e.1 = now;
            if (target - e.0).abs() < 0.0015 {
                e.0 = target;
            } else {
                e.0 += (target - e.0) * (1.0 - (-dt / GLIDE_TAU).exp());
            }
            (e.0, (target - e.0).abs() >= 0.0015)
        });
        if moving {
            self.fx.animate = true;
        }
        v
    }

    /// Circular gauge made of ticks, filling clockwise from 12 o'clock.
    pub fn ring(&mut self, cx: f32, cy: f32, diameter: f32, stroke: f32, frac: f32, color: Color) {
        let (outer, len, tw, n) = ring_geom(diameter, stroke);
        let color = themed(color);
        let key = rect_key(Rect::new(cx, cy, diameter, 0.0), "ring");
        let frac = self.glide(key, frac.clamp(0.0, 1.0));
        let pos = frac.clamp(0.0, 1.0) * n as f32;
        for i in 0..n {
            let t = (pos - i as f32).clamp(0.0, 1.0);
            self.radial_tick(cx, cy, outer, len, tw, i, n, TICK_DIM.lerp(color, t));
        }
    }

    /// The same ring for "working on it": a bright stretch of ticks that circles.
    pub fn ring_spin(&mut self, cx: f32, cy: f32, diameter: f32, stroke: f32, color: Color) {
        let (outer, len, tw, n) = ring_geom(diameter, stroke);
        let color = themed(color);
        let head = (epoch_secs() * 0.9).fract() * n as f32;
        for i in 0..n {
            let behind = (head - i as f32).rem_euclid(n as f32);
            let t = (1.0 - behind / (n as f32 * 0.35)).clamp(0.0, 1.0);
            self.radial_tick(cx, cy, outer, len, tw, i, n, TICK_DIM.lerp(color, t));
        }
        self.fx.animate = true;
    }

    #[allow(clippy::too_many_arguments)]
    fn radial_tick(&mut self, cx: f32, cy: f32, outer: f32, len: f32, tw: f32, i: usize, n: usize, c: Color) {
        let a = -std::f32::consts::FRAC_PI_2 + i as f32 * std::f32::consts::TAU / n as f32;
        let (s, co) = a.sin_cos();
        self.p.line(cx + co * (outer - len), cy + s * (outer - len), cx + co * outer, cy + s * outer, tw, c);
    }

    /// A row of thin vertical ticks that fills left to right (the app's gauge look).
    pub fn ticks(&mut self, r: Rect, frac: f32, color: Color) {
        self.ticks_ex(r, frac, color, false);
    }

    /// `warm`: the last few lit ticks warm towards yellow, like a gauge's leading edge.
    pub fn ticks_ex(&mut self, r: Rect, frac: f32, color: Color, warm: bool) {
        let frac = self.glide(rect_key(r, "ticks"), frac.clamp(0.0, 1.0));
        self.ticks_raw(r, frac, color, warm);
    }

    /// Like `ticks_ex` but draws `frac` exactly as given (the caller smooths it).
    fn ticks_raw(&mut self, r: Rect, frac: f32, color: Color, warm: bool) {
        let (n, step, w) = tick_geom(r.w);
        let color = themed(color);
        let pos = frac.clamp(0.0, 1.0) * n as f32;
        let hot = TICK_LEAD;
        for i in 0..n {
            let behind = pos - i as f32; // how far this tick is behind the leading edge
            let t = behind.clamp(0.0, 1.0);
            let mut c = TICK_DIM.lerp(color, t);
            if warm && t > 0.0 && behind < 4.0 {
                c = c.lerp(hot, (1.0 - behind / 4.0).clamp(0.0, 1.0) * t);
            }
            self.p.fill_rounded(Rect::new(r.x + i as f32 * step + (step - w) * 0.5, r.y, w, r.h), w * 0.5, c);
        }
    }

    /// Ticks with a bright stretch sliding along them ("working on it").
    pub fn ticks_sweep(&mut self, r: Rect, color: Color) {
        let (n, step, w) = tick_geom(r.w);
        let color = themed(color);
        let phase = (self.now.elapsed().as_secs_f32() + epoch_secs()) % 1.6 / 1.6;
        let head = phase * (n as f32 + 8.0) - 4.0;
        for i in 0..n {
            let t = (1.0 - (head - i as f32).abs() / 4.0).clamp(0.0, 1.0);
            self.p.fill_rounded(
                Rect::new(r.x + i as f32 * step + (step - w) * 0.5, r.y, w, r.h),
                w * 0.5,
                TICK_DIM.lerp(color, t),
            );
        }
        self.fx.animate = true;
    }

    /// Mini bar graph of recent values (0..1, oldest first): one tick per
    /// sample, taller for higher values, older ones fading out. New values
    /// glide into place.
    pub fn tick_graph(&mut self, r: Rect, values: &[f32], color: Color) {
        let n = values.len().max(1);
        let step = r.w / n as f32;
        let w = (step * 0.56).max(1.4);
        let color = themed(color);
        for (i, v) in values.iter().enumerate() {
            let v = self.glide(rect_key(r, "graph") ^ gkey("g", i), v.clamp(0.0, 1.0));
            let h = (v * r.h).max(2.0);
            let age = (i + 1) as f32 / n as f32;
            let c = TICK_DIM.lerp(color, 0.25 + 0.75 * age);
            self.p.fill_rounded(Rect::new(r.x + i as f32 * step + (step - w) * 0.5, r.bottom() - h, w, h), w * 0.5, c);
        }
    }

    /// A short faint run of ticks, used as a section rule or header accent.
    pub fn tick_rule(&mut self, r: Rect, alpha: f32) {
        let (n, step, w) = tick_geom(r.w);
        let c = Color::white(alpha);
        for i in 0..n {
            self.p.fill_rounded(Rect::new(r.x + i as f32 * step + (step - w) * 0.5, r.y, w, r.h), w * 0.5, c);
        }
    }

    /// Progress bar, drawn as ticks (the rect's height only sets how tall they are).
    pub fn progress(&mut self, r: Rect, frac: f32, color: Color) {
        let h = (r.h * 2.6).clamp(8.0, 14.0);
        self.ticks(Rect::new(r.x, r.cy() - h * 0.5, r.w, h), frac, color);
    }

    /// Indeterminate progress: a bright stretch of ticks sliding along.
    pub fn progress_indeterminate(&mut self, r: Rect, color: Color) {
        let h = (r.h * 2.6).clamp(8.0, 14.0);
        self.ticks_sweep(Rect::new(r.x, r.cy() - h * 0.5, r.w, h), color);
    }

    /// A record: dark disc, faint grooves, two sheen arcs that turn with it
    /// and a coloured label carrying the music note.
    pub fn vinyl(&mut self, r: Rect, angle: f32, label: Color, art: Option<&ImageData>) {
        let (cx, cy) = (r.cx(), r.cy());
        let rad = r.w.min(r.h) * 0.5;
        self.p.fill_circle(cx, cy, rad, Color::hex(0x0C0C0E));
        self.p.stroke_circle(cx, cy, rad - 0.5, 1.0, Color::white(0.16));
        for k in 1..=4 {
            self.p.stroke_circle(cx, cy, rad * (0.40 + 0.12 * k as f32), 0.6, Color::white(0.05));
        }
        let sheen = Color::white(0.08);
        self.p.arc(cx, cy, rad * 0.70, angle, 0.75, rad * 0.30, sheen);
        self.p.arc(cx, cy, rad * 0.70, angle + std::f32::consts::PI, 0.75, rad * 0.30, sheen);
        match art {
            // the cover is the record's label and turns with it
            Some(img) => {
                let lr = rad * 0.46;
                self.p.image_disc(img, cx, cy, lr, angle);
                self.p.stroke_circle(cx, cy, lr, 1.0, Color::black(0.55));
                self.p.fill_circle(cx, cy, rad * 0.055, Color::hex(0x0C0C0E));
                self.p.stroke_circle(cx, cy, rad * 0.055, 0.8, Color::white(0.25));
            }
            None => {
                let lr = rad * 0.38;
                self.p.fill_circle(cx, cy, lr, label.lerp(Color::black(1.0), 0.55));
                self.p.fill_circle(
                    cx + lr * 0.72 * angle.cos(),
                    cy + lr * 0.72 * angle.sin(),
                    rad * 0.035,
                    Color::white(0.45),
                );
                self.p.icon(Icon::Music, Rect::new(cx - lr * 0.5, cy - lr * 0.5, lr, lr), Color::white(0.95));
            }
        }
    }

    /// Scrubber for the media player: a row of ticks that fills as the track
    /// plays (the last few warm towards yellow), with a tall playhead on the edge.
    pub fn scrubber(&mut self, r: Rect, frac: f32, hover: bool) {
        let h = if hover { 16.0 } else { 14.0 };
        let frac = self.glide(rect_key(r, "scrub"), frac.clamp(0.0, 1.0));
        self.ticks_raw(Rect::new(r.x, r.cy() - h * 0.5, r.w, h), frac, Color::white(0.92), true);
        let px = r.x + 2.0 + (r.w - 4.0) * frac.clamp(0.0, 1.0);
        let ph = h + 8.0;
        self.p.fill_rounded(Rect::new(px - 2.2, r.cy() - ph * 0.5 + 1.0, 4.4, ph), 2.2, Color::black(0.35));
        self.p.fill_rounded(Rect::new(px - 1.8, r.cy() - ph * 0.5, 3.6, ph), 1.8, Color::white(0.97));
    }

    /// Rounded card background, highlighted on hover when `interactive`.
    pub fn card(&mut self, r: Rect, interactive: bool) -> bool {
        let hover = interactive && self.hovered(r);
        if hover {
            self.hot = true;
        }
        // flat on black: no background until hovered
        if hover {
            self.p.fill_rounded(r, 18.0, Color::white(0.05));
        }
        interactive && self.clicked(r)
    }

    /// Flat list row: no background, a hairline underneath and a soft
    /// highlight when hovered, or `tint` for the row that is in use.
    pub fn row_bg(&mut self, row: Rect, hover: bool, tint: Option<Color>) {
        match tint {
            Some(t) => self.p.fill_rounded(row, 14.0, t),
            None => {
                if hover {
                    self.p.fill_rounded(row, 14.0, Color::white(0.05));
                }
                self.p.fill_rect(
                    Rect::new(row.x + 12.0, row.bottom() - 0.5, (row.w - 24.0).max(0.0), 1.0),
                    Color::white(0.06),
                );
            }
        }
    }

    pub fn label(&mut self, s: &str, r: Rect, style: TextStyle) {
        self.p.text(s, r, &style);
    }

    /// Section header: small dim caps text.
    pub fn caption(&mut self, s: &str, r: Rect) {
        self.p.text(s, r, &TextStyle::new(11.0, palette::TEXT_FAINT).semibold());
    }

    /// Empty-state placeholder: icon + message centered in `r`.
    pub fn empty_state(&mut self, r: Rect, icon: Icon, msg: &str) {
        let is = 26.0;
        let total = is + 8.0 + 18.0;
        let top = r.cy() - total * 0.5;
        self.p.icon(icon, Rect::new(r.cx() - is * 0.5, top, is, is), palette::TEXT_FAINT);
        self.p.text(msg, Rect::new(r.x, top + is + 8.0, r.w, 18.0), &TextStyle::new(12.5, palette::TEXT_DIM).center());
    }
}

/// Seconds since process start, used to keep looping animations continuous.
pub fn epoch_secs() -> f32 {
    use std::sync::OnceLock;
    static START: OnceLock<Instant> = OnceLock::new();
    START.get_or_init(Instant::now).elapsed().as_secs_f32()
}
