# Changelog

All notable changes to Dynamic Notch are listed here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project uses [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added

- **USB drive peek**: a short notice when a drive is connected or removed. It runs only on Windows' device message, so nothing is polled.

### Changed

- **Tab slides follow your tab order**: the slide direction now comes from the order of the header tabs (including a custom order), so moving right always slides right and moving left slides left.
- **Vinyl is always a record**: the media player shows a black spinning vinyl with the album cover as its label (the music note label is used only when there is no cover). It spins while music plays and the notch is open.
- **Gemini input without an outline**: the message box and the key field are flat filled pills.
- **Icons redrawn around the beam**: slightly heavier, evenly weighted strokes, and the media, stats, Wi-Fi, volume and keyboard icons are now built from vertical beams (equalizer, load bars, signal bars, level bars, key beams).
- **Smooth tab switching**: changing pages now slides and cross-fades softly (about 0.6 s) in the direction of the tab, instead of cutting instantly. Flipping tabs with the mouse wheel is paced to match.
- **Face ID style unlock**: when the PC unlocks, the notch grows into a small square and plays a blue scan: corner brackets close in, a ring of ticks fills around a blue smiley face (it blinks once), the smiley turns into a check and "Unlocked" (or your greeting) fades in over a tick bar, then it tucks away after about two seconds.
- **Blue ticks everywhere**: every lit tick (volume and brightness HUD, peeks and notifications, rings, sliders, scrubber, battery, loading sweeps) is now the app's blue, with a light-blue leading edge instead of yellow.
- **Gemini, redesigned for real**: a header with the title, a "Context" tick meter and a tick rail that sweeps while Gemini answers; turns are separated by rows of ticks.
- **Wi-Fi and Bluetooth**: a tick strip under each header sweeps while scanning or connecting and otherwise shows signal strength (Wi-Fi) or how many devices are connected (Bluetooth); Wi-Fi rows show signal as a tick gauge.
- **Ticks in the peeks and the closed notch**: every text peek (media, notifications, Wi-Fi, Bluetooth, clipboard and more) has a rail of ticks that drains while it is shown. Caps/Num/Scroll Lock now use the tick bar like the volume HUD, full when on and empty when off. The closed notch separates its widgets with a single tick and shows the battery as a small tick gauge. Clipboard rows show how fresh each copy is and the home card shows how full the history is.
- **Smooth values everywhere**: gauges, rings, sliders, the media scrubber, percentages, the voice level meter, switches and the segmented control now ease to their new value instead of jumping. One shared helper (`Ui::glide`) does it, and it stops requesting frames the moment a value has settled, so it stays light.
- **Ticks in every module**: Stats gets a tick history graph under each ring; Clipboard, Notifications, Shelf and Dev Servers show how full they are as a tick meter; battery peeks are now tick bars like the volume HUD; Wi-Fi signal and Bluetooth battery are ticks; Weather has humidity and wind gauges plus a rain-chance row per day; Mirror has a tick ring around its button and a live indicator; Gemini shows how much of the conversation it still sees; Ask AI's thinking indicator and every loading state use the tick sweep.
- **Ticks everywhere**: the tick-bar from the volume HUD is now the app's shared gauge language. Progress bars, sliders, the media scrubber, timer and battery rings, battery icons and loading states are all drawn from the same fine ticks, with a travelling sweep while something is loading (including the Mirror camera starting up).
- **Gemini redesign**: the chat now matches the rest of the panel. Your messages are white capsules, Gemini's answers are plain text on black, hairlines separate the turns, a tick sweep shows it is thinking, and the blue accent is gone. Same features, same key handling.
- **Smoother open and close**: the live backdrop blur is skipped while the panel is opaque and while it is moving, GPU caches are kept for 30 s instead of 3 s so the next open does not rebuild them, content fades in sooner, springs settle faster with less overshoot, and the compositor is no longer sent unchanged blur settings every frame.
- **Media player layout**: the transport buttons no longer overlap the scrubber; the times sit on either side of the buttons.
- **Overhauled panel look** (inspired by NotchNook and similar notches): a pure black panel (`expanded_opacity` now defaults to 1.0), flat home columns separated by hairlines instead of cards, plain icon tabs with the open one as a white labeled pill, rounder panel corners and album art, and larger transport buttons. Every tab follows suit: list rows (Clipboard, Wi-Fi, Bluetooth, Downloads, Dev Servers, Notifications, Dictation history, Settings) are flat with hairline separators and a soft highlight on hover, and the weather page uses dividers instead of cards. Nothing about what the app does has changed.
- **More Mac-like panel**: the open tab in the header is a white pill with its name, tiles are rounder (16 px) with a faint light edge, and the media scrubber is now glassy: a frosted track, a sheen along the fill and a translucent bead.
- **Unlock-pill style everywhere**: every peek now uses a plain white icon on the left and a small coloured status badge on the right (green check, warning mark, or a dot), in a slimmer, rounder pill. Icon-only peeks are even more compact.
- **Volume and brightness HUD**: icon top left, percentage top right and a bar of thin ticks underneath, with the leading ticks warming to yellow.
- **Unlock greeting** is now just the padlock and a green check. Set `[greeting] name` to get the "Good morning, Sam" text and date back.

- **Tab order is yours**: Settings → Tabs reorders the header tabs with ‹ › arrows (`[tabs] order` in the config). Home stays first.

- Home and notch widgets can be reordered with ‹ › arrows (Settings → Home / Notch).
- Gemini tab redone with very round corners: pill-shaped input, bubble messages and a soft rounded panel.
- The unlock greeting uses a plain white unlocked padlock instead of the sparkle in a coloured circle.

- **New look, inspired by Bloom**: black glass notch with rounder bottom corners and larger concave ears, 12 px tiles with a hairline border, round header buttons where the open tab is a white circle with a dark icon, white "active" controls (selected chips, segmented buttons, primary buttons), thin thumbless sliders, green iOS-style switches, a white play button, and an Inter-first font (used when Inter is installed; otherwise Segoe UI Variable). Expanded opacity default is now 0.92.
- **System stats page**: three big rings (CPU, memory, graphics). Click the stats widget on the home page to open it.

- Scroll the mouse wheel over the header to flip through the tabs.
- The system stats widget shows CPU, RAM and GPU as three rings instead of three bars.

- All icons are now drawn as thin rounded vector outlines in the style of macOS SF Symbols (no icon font needed any more). Media transport buttons stay filled.

### Added

- **Mirror** tab: a small live camera preview that only runs after you press the Mirror button. It switches off when you close it, leave the tab or close the notch (`mirror = false` under `[modules]` removes the tab).
- **Spinning vinyl** instead of a bare music icon when a track has no artwork (the open player turns it at 30 fps; the closed notch shows it still, so playback stays free).

- **Settings** tab: general options, look (glass, opacity, size, bounce, speed, accent), home widgets, module switches, weather city and units, Gemini key and model.
- **Customizable home page**: choose up to four widgets (`[home] widgets`). The clock now stays on the left: a strip under the media player while something plays, the big clock otherwise.
- **Weather** tab and home widget (Open-Meteo, no key).
- **Control Center** tab (Wi-Fi and Bluetooth in one): two buttons at the top slide between the lists. Wi-Fi: scan, connect, disconnect, radio switch. Bluetooth: scan, pair, connect (best effort), disconnect, remove, radio switch. One home widget with a half for each.
- **Notifications**: Windows notifications peek in the notch (needs Windows' notification access), with a short history tab.
- **Gemini** tab with in-app API key entry (saved to `%APPDATA%\DynamicNotch\.env`).
- **Notes** tab and widget.
- **Unlock greeting**: a short "Good morning, Sam" peek with the date when you unlock the PC (`[greeting] name`, switch off in Settings).
- **Disconnect** button for connected Bluetooth devices (keeps them paired; works for headphones, speakers and similar).
- Header tabs shrink when many modules are enabled; the Settings gear sits at the right end of the header, next to the battery.
- More breathing room when expanded: wider default panel (720), larger padding and rows. Panel width is adjustable in Settings → Look.
- Gemini chat shows the whole conversation, with a compact input at the bottom.

## [0.1.0] - 2026-10-08

The first public release.

### Notch

- A MacBook-style notch at the top of the screen that rests, shows live activities, peeks on events and opens into a frosted-glass panel.
- Spring animations, hover lean, fast collapse when the mouse leaves.
- Hides automatically for fullscreen games, videos and presentations.
- Idle styles: always-visible notch, slim pill, or hidden until something happens.
- Primary monitor, a fixed monitor, or follow the active window.
- Per-monitor DPI aware; renders with Direct2D on a composition swap chain and draws nothing while idle.

### Modules

- **Media**: artwork, title and controls for anything using the Windows media controls, with a compositor-driven visualizer tinted from the album art.
- **Timer**: timers and a stopwatch with a countdown ring in the notch and a chime when done.
- **Downloads**: browser downloads with size and speed, and a peek when they finish.
- **Clipboard**: in-memory history of text, links, files and images; content flagged by password managers is skipped.
- **Shelf**: drop files on the notch to park them, drag them out later.
- **Dictation**: hold or tap `Ctrl+Alt+D`, speak, and the text is pasted into the app you were using (Whisper on Groq, with an optional clean-up pass).
- **Ask AI**: a quick prompt on `Ctrl+Alt+Space` with streamed answers and follow-ups, through any OpenRouter model.
- **Mic and camera**: an indicator and a peek naming the app whenever the microphone or camera is in use.
- **Ports**: local dev servers as they start listening, each with an Open button.
- **Lock keys**: peeks for Caps Lock, Num Lock and Scroll Lock.
- **Battery**: level and charging state, with peeks for plugged in, unplugged, low and full.
- **Volume and brightness**: the notch replaces the Windows volume flyout; brightness changes on the built-in display peek too.
- **Bluetooth**: connect and disconnect peeks with the device's battery level, and a low-battery warning.
- **System stats**: CPU, RAM and GPU load on the home page, sampled only while the notch is open.

### Integrations

- Command-line API: `notify`, `progress`, `timer`, `ask`, `toggle`, `expand`, `collapse`, `ai`, `reload` and `quit` are forwarded to the running notch.
- Claude Code hook bridge: `dynamic-notch claude` peeks when Claude finishes or needs you and brings its terminal back on click.
- Tray icon with modules, monitor, display options and autostart.
- `%APPDATA%\DynamicNotch\config.toml` with hot reload; API keys are read only from the environment or a git-ignored `.env`.

[Unreleased]: https://github.com/eigenes/DynamicNotch/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/eigenes/DynamicNotch/releases/tag/v0.1.0
