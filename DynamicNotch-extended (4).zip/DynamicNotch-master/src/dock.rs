//! A macOS-style dock that replaces the Windows taskbar.
//!
//! * Its own topmost window at the bottom of the screen, drawn with the same
//!   Direct2D painter as the notch (sharing the notch's compositor).
//! * The plate has concave corners where it meets the screen edge, like the
//!   notch has at the top.
//! * Icons come from the apps themselves, or from PNG files in the icons
//!   folder (`chrome.png`, `explorer.png`, `start.png`, ...).
//! * Icons grow near the mouse (magnification); size and strength are settings.
//! * The Windows taskbar is hidden while the dock is on and restored when it
//!   is switched off or the app quits. Work area space is reserved with an
//!   app bar so maximized windows stop above the dock.
//!
//! Running apps are found by scanning top-level windows once a second (only
//! while the dock is on); everything else is event driven.

use std::collections::HashMap;
use std::ffi::c_void;
use std::path::{Path, PathBuf};
use std::time::{Instant, SystemTime};

use windows::core::{w, Result, HSTRING, PCWSTR, PWSTR};
use windows::Win32::Foundation::{CloseHandle, BOOL, HWND, LPARAM, LRESULT, POINT, RECT, SIZE, WPARAM};
use windows::Win32::Graphics::Dwm::{
    DwmGetWindowAttribute, DwmSetWindowAttribute, DWMWA_BORDER_COLOR, DWMWA_CLOAKED, DWMWA_EXCLUDED_FROM_PEEK,
    DWMWA_WINDOW_CORNER_PREFERENCE, DWMWCP_DONOTROUND,
};
use windows::Win32::Graphics::Gdi::{
    CreateRectRgn, DeleteObject, GetDC, GetDIBits, GetMonitorInfoW, GetObjectW, MonitorFromPoint, ReleaseDC, BITMAP,
    BITMAPINFO, BITMAPINFOHEADER, DIB_RGB_COLORS, HBITMAP, MONITORINFO, MONITOR_DEFAULTTOPRIMARY,
};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Threading::{
    OpenProcess, QueryFullProcessImageNameW, PROCESS_NAME_FORMAT, PROCESS_QUERY_LIMITED_INFORMATION,
};
use windows::Win32::UI::HiDpi::{GetDpiForMonitor, MDT_EFFECTIVE_DPI};
use windows::Win32::UI::Input::KeyboardAndMouse::{
    keybd_event, TrackMouseEvent, KEYBD_EVENT_FLAGS, KEYEVENTF_KEYUP, TME_LEAVE, TRACKMOUSEEVENT, VK_LWIN,
};
use windows::Win32::UI::Shell::{
    IShellItemImageFactory, SHAppBarMessage, SHCreateItemFromParsingName, ABE_BOTTOM, ABM_GETSTATE, ABM_NEW,
    ABM_QUERYPOS, ABM_REMOVE, ABM_SETPOS, ABM_SETSTATE, ABS_AUTOHIDE, APPBARDATA, SIIGBF_BIGGERSIZEOK, SIIGBF_ICONONLY,
};
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::config::{self, Config, DockCfg};
use crate::gfx::{image, Gfx, ImageData, Painter, Res, TextStyle};
use crate::host::Host;
use crate::util::{palette, Color, Rect, SendHwnd};
use crate::window::with_app;

const CLASS_NAME: PCWSTR = w!("DynamicNotch.Dock");
const TIMER_ANIM: usize = 1;
const TIMER_SCAN: usize = 2;
const WM_APPBAR: u32 = WM_APP + 30;

const GAP: f32 = 8.0;
const PAD_X: f32 = 14.0;
const PAD_Y: f32 = 10.0;
const SEP_W: f32 = 14.0;
/// Space above the tallest icon for the name label.
const LABEL_ROOM: f32 = 44.0;

// context menu commands
const CMD_OPEN: u32 = 1;
const CMD_PIN: u32 = 2;
const CMD_CLOSE: u32 = 3;
const CMD_SETTINGS: u32 = 4;

/// Borrowed pieces of the app the dock needs to draw.
pub struct Ctx<'a> {
    pub gfx: &'a Gfx,
    pub res: &'a mut Res,
    pub cfg: &'a Config,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Kind {
    Start,
    App,
}

#[derive(Clone, PartialEq, Debug)]
struct Item {
    kind: Kind,
    /// Full path of the executable (empty for Start).
    exe: String,
    name: String,
    pinned: bool,
    /// Open windows of this app (HWND values).
    windows: Vec<isize>,
}

/// What the right-click menu needs to know about an item.
pub struct MenuInfo {
    pub index: usize,
    pub start: bool,
    pub pinned: bool,
    pub running: bool,
}

struct Geo {
    icons: Vec<Rect>,
    plate: Rect,
}

pub struct Dock {
    pub hwnd: HWND,
    host: Host,
    cfg: DockCfg,
    scale: f32,
    /// Window size in logical pixels.
    win_w: f32,
    win_h: f32,
    win_px: (i32, i32, i32, i32),
    monitor_rect: RECT,
    items: Vec<Item>,
    /// Index after which the separator between pinned and other apps is drawn.
    sep: Option<usize>,
    zoom: Vec<f32>,
    mouse: Option<(f32, f32)>,
    tracking: bool,
    press: Option<usize>,
    animating: bool,
    last_frame: Instant,
    icons: HashMap<String, Option<ImageData>>,
    overrides: HashMap<String, PathBuf>,
    icons_dir: PathBuf,
    icons_mtime: Option<SystemTime>,
    fg: HWND,
    fs_hidden: bool,
    region: Option<(i32, i32, i32, i32)>,
    appbar: bool,
    reserved_px: i32,
    hidden_bars: Vec<isize>,
    saved_bar_state: Option<usize>,
    lost: bool,
}

// ---------------------------------------------------------------------------
// Window
// ---------------------------------------------------------------------------

fn create_window() -> Result<HWND> {
    unsafe {
        let hinst = GetModuleHandleW(None)?;
        let wc = WNDCLASSEXW {
            cbSize: std::mem::size_of::<WNDCLASSEXW>() as u32,
            lpfnWndProc: Some(wndproc),
            hInstance: hinst.into(),
            hCursor: LoadCursorW(None, IDC_ARROW)?,
            lpszClassName: CLASS_NAME,
            ..Default::default()
        };
        RegisterClassExW(&wc);
        let hwnd = CreateWindowExW(
            WS_EX_NOREDIRECTIONBITMAP | WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_NOACTIVATE,
            CLASS_NAME,
            w!("Dynamic Notch Dock"),
            WS_POPUP,
            0,
            0,
            1,
            1,
            None,
            None,
            Some(hinst.into()),
            None,
        )?;
        let no_round = DWMWCP_DONOTROUND;
        let _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_WINDOW_CORNER_PREFERENCE,
            &no_round as *const _ as _,
            std::mem::size_of_val(&no_round) as u32,
        );
        let on = BOOL(1);
        let _ = DwmSetWindowAttribute(hwnd, DWMWA_EXCLUDED_FROM_PEEK, &on as *const _ as _, 4);
        let none: u32 = 0xFFFF_FFFE; // DWMWA_COLOR_NONE
        let _ = DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR, &none as *const _ as _, 4);
        Ok(hwnd)
    }
}

extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match std::panic::catch_unwind(|| wndproc_inner(hwnd, msg, wp, lp)) {
        Ok(r) => r,
        Err(_) => {
            crate::log!("dock: recovered from panic while handling message {msg:#x}");
            unsafe { DefWindowProcW(hwnd, msg, wp, lp) }
        }
    }
}

fn wndproc_inner(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    // The context menu runs a modal loop: show it outside the app borrow.
    if msg == WM_RBUTTONUP {
        if let Some(Some(info)) = with_app(|a| a.dock_menu_info(hwnd, lp)) {
            let cmd = show_menu(hwnd, &info);
            if cmd != 0 {
                with_app(|a| a.dock_command(info.index, cmd));
            }
        }
        return LRESULT(0);
    }
    match with_app(|a| a.dock_msg(hwnd, msg, wp, lp)) {
        Some(Some(r)) => r,
        _ => unsafe { DefWindowProcW(hwnd, msg, wp, lp) },
    }
}

fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(std::iter::once(0)).collect()
}

fn show_menu(hwnd: HWND, info: &MenuInfo) -> u32 {
    unsafe {
        let Ok(menu) = CreatePopupMenu() else { return 0 };
        let add = |id: u32, text: &str| {
            let t = wide(text);
            let _ = AppendMenuW(menu, MF_STRING, id as usize, PCWSTR(t.as_ptr()));
        };
        if !info.start {
            add(CMD_OPEN, if info.running { "Open new window" } else { "Open" });
            add(CMD_PIN, if info.pinned { "Remove from dock" } else { "Keep in dock" });
            if info.running {
                add(CMD_CLOSE, "Close window");
            }
            let _ = AppendMenuW(menu, MF_SEPARATOR, 0, None);
        }
        add(CMD_SETTINGS, "Dock settings…");
        let mut pt = POINT::default();
        let _ = GetCursorPos(&mut pt);
        let _ = SetForegroundWindow(hwnd);
        let cmd = TrackPopupMenuEx(menu, (TPM_RETURNCMD | TPM_NONOTIFY | TPM_RIGHTBUTTON | TPM_BOTTOMALIGN).0, pt.x, pt.y, hwnd, None);
        let _ = PostMessageW(Some(hwnd), WM_NULL, WPARAM(0), LPARAM(0));
        let _ = DestroyMenu(menu);
        cmd.0 as u32
    }
}

// ---------------------------------------------------------------------------
// Dock
// ---------------------------------------------------------------------------

impl Dock {
    pub fn create(gfx: &Gfx, compositor: &windows::UI::Composition::Compositor, cfg: &Config) -> Result<Dock> {
        let hwnd = create_window()?;
        let host = match Host::new_shared(hwnd, gfx, 64, 64, compositor) {
            Ok(h) => h,
            Err(e) => {
                unsafe {
                    let _ = DestroyWindow(hwnd);
                }
                return Err(e);
            }
        };
        let mut d = Dock {
            hwnd,
            host,
            cfg: cfg.dock.clone(),
            scale: 1.0,
            win_w: 0.0,
            win_h: 0.0,
            win_px: (0, 0, 0, 0),
            monitor_rect: RECT::default(),
            items: Vec::new(),
            sep: None,
            zoom: Vec::new(),
            mouse: None,
            tracking: false,
            press: None,
            animating: false,
            last_frame: Instant::now(),
            icons: HashMap::new(),
            overrides: HashMap::new(),
            icons_dir: PathBuf::new(),
            icons_mtime: None,
            fg: HWND::default(),
            fs_hidden: false,
            region: None,
            appbar: false,
            reserved_px: 0,
            hidden_bars: Vec::new(),
            saved_bar_state: None,
            lost: false,
        };
        d.reconfigure_inner(cfg);
        unsafe {
            SetTimer(Some(hwnd), TIMER_SCAN, 1000, None);
        }
        Ok(d)
    }

    /// Settings changed (or first start).
    pub fn reconfigure(&mut self, ctx: &mut Ctx) {
        self.reconfigure_inner(ctx.cfg);
        self.render(ctx);
    }

    fn reconfigure_inner(&mut self, cfg: &Config) {
        self.cfg = cfg.dock.clone();
        let dir = if self.cfg.icons_dir.trim().is_empty() {
            crate::util::app_dir().join("dock-icons")
        } else {
            PathBuf::from(self.cfg.icons_dir.trim())
        };
        let _ = std::fs::create_dir_all(&dir);
        self.icons_dir = dir;
        self.icons.clear();
        self.icons_mtime = None;
        self.refresh_overrides();
        self.rescan(true);
        self.place();
        if self.cfg.hide_taskbar {
            self.enforce_taskbar_hidden();
        } else {
            self.restore_taskbars();
        }
    }

    /// Restore everything we changed on the system and close the window.
    pub fn shutdown(&mut self) {
        unsafe {
            let _ = KillTimer(Some(self.hwnd), TIMER_ANIM);
            let _ = KillTimer(Some(self.hwnd), TIMER_SCAN);
        }
        self.restore_taskbars();
        self.release_space();
        unsafe {
            let _ = DestroyWindow(self.hwnd);
        }
    }

    pub fn take_lost(&mut self) -> bool {
        std::mem::take(&mut self.lost)
    }

    pub fn set_rendering_device(&mut self, gfx: &Gfx) {
        let _ = self.host.set_rendering_device(gfx);
    }

    // -- geometry -----------------------------------------------------------

    fn sizes(&self) -> (f32, f32, f32) {
        let s = self.cfg.icon_size;
        (s, s + 2.0 * PAD_Y, self.cfg.magnification.max(1.0))
    }

    fn geometry(&self, zoom: &[f32]) -> Geo {
        let (s, plate_h, _) = self.sizes();
        let n = self.items.len();
        let sepw = if self.sep.is_some() { SEP_W } else { 0.0 };
        let content: f32 =
            (0..n).map(|i| s * zoom.get(i).copied().unwrap_or(1.0)).sum::<f32>() + GAP * n.saturating_sub(1) as f32 + sepw;
        let plate_w = content + 2.0 * PAD_X;
        let left = self.win_w * 0.5 - plate_w * 0.5;
        let mut x = left + PAD_X;
        let mut icons = Vec::with_capacity(n);
        for i in 0..n {
            let z = s * zoom.get(i).copied().unwrap_or(1.0);
            icons.push(Rect::new(x, self.win_h - PAD_Y - z, z, z));
            x += z + GAP;
            if self.sep == Some(i) {
                x += sepw;
            }
        }
        Geo { icons, plate: Rect::new(left, self.win_h - plate_h, plate_w, plate_h) }
    }

    /// Where the dock goes: bottom center of the primary monitor.
    fn place(&mut self) {
        unsafe {
            let mon = MonitorFromPoint(POINT { x: 0, y: 0 }, MONITOR_DEFAULTTOPRIMARY);
            let mut mi = MONITORINFO { cbSize: std::mem::size_of::<MONITORINFO>() as u32, ..Default::default() };
            if !GetMonitorInfoW(mon, &mut mi).as_bool() {
                return;
            }
            let (mut dx, mut dy) = (96u32, 96u32);
            let _ = GetDpiForMonitor(mon, MDT_EFFECTIVE_DPI, &mut dx, &mut dy);
            let scale = dx as f32 / 96.0;
            let m = mi.rcMonitor;
            self.monitor_rect = m;
            let (s, plate_h, mag) = self.sizes();
            let n = self.items.len().max(1) as f32;
            let max_w = n * s * mag + GAP * (n - 1.0) + SEP_W + 2.0 * PAD_X + 2.0 * self.cfg.ear + 80.0;
            let mon_w = (m.right - m.left) as f32 / scale;
            let win_w = max_w.min(mon_w);
            let win_h = plate_h + s * (mag - 1.0) + LABEL_ROOM;
            let wpx = (win_w * scale).ceil() as i32;
            let hpx = (win_h * scale).ceil() as i32;
            let x = (m.left + m.right) / 2 - wpx / 2;
            let y = m.bottom - hpx;
            let geom = (x, y, wpx, hpx);
            if geom != self.win_px || (scale - self.scale).abs() > 0.001 {
                self.scale = scale;
                self.win_w = win_w;
                self.win_h = win_h;
                self.win_px = geom;
                let _ = SetWindowPos(self.hwnd, Some(HWND_TOPMOST), x, y, wpx, hpx, SWP_NOACTIVATE);
                let _ = self.host.resize(wpx, hpx);
                self.region = None;
            }
            if !self.fs_hidden {
                let _ = ShowWindow(self.hwnd, SW_SHOWNOACTIVATE);
            }
            let plate_px = (plate_h * scale).ceil() as i32;
            self.reserve_space(plate_px);
        }
        self.update_region();
    }

    /// Only the dock itself receives the mouse; the rest of the window lets
    /// clicks through to whatever is behind it.
    fn update_region(&mut self) {
        let n = self.items.len();
        let s = self.scale;
        let (_, plate_h, _) = self.sizes();
        let g = self.geometry(&self.zoom);
        let ear = self.cfg.ear;
        let active = self.mouse.is_some() || self.animating;
        let px = if n == 0 || self.fs_hidden {
            (0, 0, 0, 0)
        } else if active {
            // room for the magnified icons and the label
            (
                ((g.plate.x - ear) * s).floor().max(0.0) as i32,
                0,
                ((g.plate.right() + ear) * s).ceil() as i32,
                self.win_px.3,
            )
        } else {
            (
                ((g.plate.x - ear) * s).floor().max(0.0) as i32,
                ((self.win_h - plate_h) * s).floor().max(0.0) as i32,
                ((g.plate.right() + ear) * s).ceil() as i32,
                self.win_px.3,
            )
        };
        if self.region != Some(px) {
            self.region = Some(px);
            unsafe {
                let rgn = CreateRectRgn(px.0, px.1, px.2, px.3);
                SetWindowRgn(self.hwnd, Some(rgn), false);
            }
        }
    }

    // -- items --------------------------------------------------------------

    fn rescan(&mut self, force: bool) -> bool {
        let mut items: Vec<Item> = Vec::new();
        if self.cfg.show_start {
            items.push(Item { kind: Kind::Start, exe: String::new(), name: "Start".into(), pinned: true, windows: vec![] });
        }
        for path in &self.cfg.pinned {
            items.push(Item { kind: Kind::App, exe: path.clone(), name: stem_of(path), pinned: true, windows: vec![] });
        }
        let pinned_end = items.len();
        for (hwnd, exe) in running_windows() {
            let hit = items.iter_mut().find(|i| i.kind == Kind::App && same_path(&i.exe, &exe));
            match hit {
                Some(it) => it.windows.push(hwnd),
                None if self.cfg.show_running => items.push(Item {
                    kind: Kind::App,
                    name: stem_of(&exe),
                    exe,
                    pinned: false,
                    windows: vec![hwnd],
                }),
                None => {}
            }
        }
        let sep = if pinned_end > 0 && items.len() > pinned_end { Some(pinned_end - 1) } else { None };
        if !force && items == self.items && sep == self.sep {
            return false;
        }
        self.items = items;
        self.sep = sep;
        self.zoom.resize(self.items.len(), 1.0);
        for z in self.zoom.iter_mut() {
            *z = 1.0;
        }
        true
    }

    // -- icons --------------------------------------------------------------

    fn refresh_overrides(&mut self) {
        self.overrides.clear();
        if let Ok(rd) = std::fs::read_dir(&self.icons_dir) {
            for e in rd.flatten() {
                let p = e.path();
                let is_png = p.extension().is_some_and(|x| x.eq_ignore_ascii_case("png"));
                if let (true, Some(stem)) = (is_png, p.file_stem().and_then(|s| s.to_str())) {
                    self.overrides.insert(stem.to_lowercase(), p.clone());
                }
            }
        }
        self.icons_mtime = std::fs::metadata(&self.icons_dir).and_then(|m| m.modified()).ok();
    }

    fn icon_for(&mut self, item: &Item) -> Option<ImageData> {
        let key = match item.kind {
            Kind::Start => "start".to_string(),
            Kind::App => item.exe.to_lowercase(),
        };
        if let Some(v) = self.icons.get(&key) {
            return v.clone();
        }
        let stem = match item.kind {
            Kind::Start => "start".to_string(),
            Kind::App => stem_of(&item.exe).to_lowercase(),
        };
        let mut img = self
            .overrides
            .get(&stem)
            .and_then(|p| std::fs::read(p).ok())
            .and_then(|bytes| image::decode(&bytes, 256));
        if img.is_none() && item.kind == Kind::App {
            img = unsafe { shell_icon(&item.exe, 128) };
        }
        self.icons.insert(key, img.clone());
        img
    }

    // -- taskbar & work area ---------------------------------------------------

    fn enforce_taskbar_hidden(&mut self) {
        unsafe {
            if self.saved_bar_state.is_none() {
                let mut abd = APPBARDATA { cbSize: std::mem::size_of::<APPBARDATA>() as u32, ..Default::default() };
                let st = SHAppBarMessage(ABM_GETSTATE, &mut abd);
                self.saved_bar_state = Some(st);
                abd.lParam = LPARAM((st | ABS_AUTOHIDE as usize) as isize);
                SHAppBarMessage(ABM_SETSTATE, &mut abd);
            }
            let mut bars: Vec<HWND> = Vec::new();
            if let Ok(h) = FindWindowW(w!("Shell_TrayWnd"), PCWSTR::null()) {
                bars.push(h);
            }
            let mut prev: Option<HWND> = None;
            while let Ok(h) = FindWindowExW(None, prev, w!("Shell_SecondaryTrayWnd"), PCWSTR::null()) {
                if h.is_invalid() {
                    break;
                }
                bars.push(h);
                prev = Some(h);
            }
            for h in bars {
                if IsWindowVisible(h).as_bool() {
                    let _ = ShowWindow(h, SW_HIDE);
                }
                let v = h.0 as isize;
                if !self.hidden_bars.contains(&v) {
                    self.hidden_bars.push(v);
                }
            }
        }
    }

    fn restore_taskbars(&mut self) {
        unsafe {
            for v in self.hidden_bars.drain(..) {
                let h = SendHwnd(v).hwnd();
                if IsWindow(Some(h)).as_bool() {
                    let _ = ShowWindow(h, SW_SHOWNOACTIVATE);
                }
            }
            if let Some(st) = self.saved_bar_state.take() {
                let mut abd = APPBARDATA { cbSize: std::mem::size_of::<APPBARDATA>() as u32, ..Default::default() };
                abd.lParam = LPARAM(st as isize);
                SHAppBarMessage(ABM_SETSTATE, &mut abd);
            }
        }
    }

    /// Keep maximized windows above the dock.
    fn reserve_space(&mut self, plate_px: i32) {
        if !self.cfg.reserve_space || self.fs_hidden {
            self.release_space();
            return;
        }
        if self.appbar && self.reserved_px == plate_px {
            return;
        }
        unsafe {
            let mut abd = APPBARDATA {
                cbSize: std::mem::size_of::<APPBARDATA>() as u32,
                hWnd: self.hwnd,
                uCallbackMessage: WM_APPBAR,
                ..Default::default()
            };
            if !self.appbar {
                SHAppBarMessage(ABM_NEW, &mut abd);
                self.appbar = true;
            }
            let m = self.monitor_rect;
            abd.uEdge = ABE_BOTTOM;
            abd.rc = RECT { left: m.left, top: m.bottom - plate_px, right: m.right, bottom: m.bottom };
            SHAppBarMessage(ABM_QUERYPOS, &mut abd);
            abd.rc.top = abd.rc.bottom - plate_px;
            SHAppBarMessage(ABM_SETPOS, &mut abd);
        }
        self.reserved_px = plate_px;
    }

    fn release_space(&mut self) {
        if self.appbar {
            unsafe {
                let mut abd = APPBARDATA {
                    cbSize: std::mem::size_of::<APPBARDATA>() as u32,
                    hWnd: self.hwnd,
                    ..Default::default()
                };
                SHAppBarMessage(ABM_REMOVE, &mut abd);
            }
            self.appbar = false;
            self.reserved_px = 0;
        }
    }

    fn check_fullscreen(&mut self) {
        let fg = unsafe { GetForegroundWindow() };
        let mut hide = false;
        if !fg.is_invalid() && fg != self.hwnd {
            unsafe {
                let mut r = RECT::default();
                let mut buf = [0u16; 64];
                let n = GetClassNameW(fg, &mut buf).max(0) as usize;
                let class = String::from_utf16_lossy(&buf[..n]);
                let shell = matches!(class.as_str(), "Progman" | "WorkerW" | "Shell_TrayWnd");
                if !shell && GetWindowRect(fg, &mut r).is_ok() {
                    let m = self.monitor_rect;
                    hide = r.left <= m.left && r.top <= m.top && r.right >= m.right && r.bottom >= m.bottom;
                }
            }
        }
        if hide != self.fs_hidden {
            self.fs_hidden = hide;
            unsafe {
                let _ = ShowWindow(self.hwnd, if hide { SW_HIDE } else { SW_SHOWNOACTIVATE });
            }
            if hide {
                self.release_space();
            } else {
                self.reserved_px = 0;
                self.place();
            }
        }
    }

    // -- input ------------------------------------------------------------------

    fn hit(&self, x: f32, y: f32) -> Option<usize> {
        let g = self.geometry(&self.zoom);
        g.icons.iter().position(|r| x >= r.x - GAP * 0.5 && x < r.right() + GAP * 0.5 && y >= r.y - 4.0)
    }

    fn click(&mut self, idx: usize) {
        let Some(item) = self.items.get(idx).cloned() else { return };
        match item.kind {
            Kind::Start => unsafe {
                keybd_event(VK_LWIN.0 as u8, 0, KEYBD_EVENT_FLAGS(0), 0);
                keybd_event(VK_LWIN.0 as u8, 0, KEYEVENTF_KEYUP, 0);
            },
            Kind::App if item.windows.is_empty() => crate::sys::shell_open(&item.exe),
            Kind::App => unsafe {
                let list: Vec<HWND> = item.windows.iter().map(|&v| SendHwnd(v).hwnd()).collect();
                let fg = GetForegroundWindow();
                match list.iter().position(|&h| h == fg) {
                    Some(_) if list.len() == 1 => {
                        let _ = ShowWindow(fg, SW_MINIMIZE);
                    }
                    Some(i) => focus(list[(i + 1) % list.len()]),
                    None => focus(list[0]),
                }
            },
        }
    }

    pub fn menu_info(&self, lp: LPARAM) -> Option<MenuInfo> {
        let (x, y) = self.lp_logical(lp);
        let index = self.hit(x, y)?;
        let it = self.items.get(index)?;
        Some(MenuInfo { index, start: it.kind == Kind::Start, pinned: it.pinned, running: !it.windows.is_empty() })
    }

    /// A right-click menu entry was chosen. Returns a notch page to open.
    pub fn command(&mut self, idx: usize, cmd: u32) -> Option<&'static str> {
        let item = self.items.get(idx)?.clone();
        match cmd {
            CMD_OPEN => {
                if item.kind == Kind::App {
                    crate::sys::shell_open(&item.exe);
                }
            }
            CMD_PIN => {
                let mut list = self.cfg.pinned.clone();
                if item.pinned {
                    list.retain(|p| !same_path(p, &item.exe));
                } else {
                    list.push(item.exe.clone());
                }
                let value = format!(
                    "[{}]",
                    list.iter().map(|p| crate::modules::widgets::toml_str(p)).collect::<Vec<_>>().join(", ")
                );
                config::set_value("dock", "pinned", &value);
            }
            CMD_CLOSE => unsafe {
                for &v in &item.windows {
                    let _ = PostMessageW(Some(SendHwnd(v).hwnd()), WM_CLOSE, WPARAM(0), LPARAM(0));
                }
            },
            CMD_SETTINGS => return Some("settings"),
            _ => {}
        }
        None
    }

    fn lp_logical(&self, lp: LPARAM) -> (f32, f32) {
        let x = (lp.0 & 0xFFFF) as i16 as f32 / self.scale;
        let y = ((lp.0 >> 16) & 0xFFFF) as i16 as f32 / self.scale;
        (x, y)
    }

    /// Window messages for the dock. Returns `None` for the default handling.
    pub fn handle(&mut self, msg: u32, wp: WPARAM, lp: LPARAM, ctx: &mut Ctx) -> Option<LRESULT> {
        match msg {
            WM_MOUSEMOVE => {
                if !self.tracking {
                    let mut tme = TRACKMOUSEEVENT {
                        cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32,
                        dwFlags: TME_LEAVE,
                        hwndTrack: self.hwnd,
                        dwHoverTime: 0,
                    };
                    unsafe {
                        let _ = TrackMouseEvent(&mut tme);
                    }
                    self.tracking = true;
                }
                let was_idle = self.mouse.is_none();
                self.mouse = Some(self.lp_logical(lp));
                if was_idle {
                    self.update_region();
                }
                self.start_animation();
                self.render(ctx);
                Some(LRESULT(0))
            }
            WM_MOUSELEAVE => {
                self.tracking = false;
                self.mouse = None;
                self.press = None;
                self.start_animation();
                self.render(ctx);
                Some(LRESULT(0))
            }
            WM_LBUTTONDOWN => {
                let (x, y) = self.lp_logical(lp);
                self.press = self.hit(x, y);
                Some(LRESULT(0))
            }
            WM_LBUTTONUP => {
                let (x, y) = self.lp_logical(lp);
                let hit = self.hit(x, y);
                if hit.is_some() && hit == self.press {
                    self.click(hit.unwrap_or(0));
                }
                self.press = None;
                Some(LRESULT(0))
            }
            WM_MOUSEACTIVATE => Some(LRESULT(MA_NOACTIVATE as isize)),
            WM_TIMER => {
                match wp.0 {
                    TIMER_ANIM => self.animate(ctx),
                    TIMER_SCAN => self.scan_tick(ctx),
                    _ => return None,
                }
                Some(LRESULT(0))
            }
            WM_DISPLAYCHANGE | WM_DPICHANGED => {
                self.win_px = (0, 0, 0, 0);
                self.place();
                self.render(ctx);
                Some(LRESULT(0))
            }
            _ => None,
        }
    }

    // -- animation ------------------------------------------------------------

    fn start_animation(&mut self) {
        if !self.animating {
            self.animating = true;
            self.last_frame = Instant::now();
            unsafe {
                SetTimer(Some(self.hwnd), TIMER_ANIM, 16, None);
            }
            self.update_region();
        }
    }

    /// Where each icon wants to be, given the mouse. The cursor is mapped
    /// back into the un-magnified layout so the bump follows it exactly.
    fn target_zoom(&self) -> Vec<f32> {
        let n = self.items.len();
        let (s, _, mag) = self.sizes();
        let Some((mx, _)) = self.mouse else { return vec![1.0; n] };
        if n == 0 || mag <= 1.001 {
            return vec![1.0; n];
        }
        let now = self.geometry(&self.zoom);
        let base = self.geometry(&vec![1.0; n]);
        let mut bx = mx;
        if mx < now.icons[0].x {
            bx = base.icons[0].x - (now.icons[0].x - mx);
        } else if mx >= now.icons[n - 1].right() {
            bx = base.icons[n - 1].right() + (mx - now.icons[n - 1].right());
        } else {
            for i in 0..n {
                let r = now.icons[i];
                if mx >= r.x - GAP * 0.5 && mx < r.right() + GAP * 0.5 {
                    let t = ((mx - r.x) / r.w).clamp(0.0, 1.0);
                    bx = base.icons[i].x + t * base.icons[i].w;
                    break;
                }
            }
        }
        let spread = self.cfg.spread.max(0.5);
        (0..n)
            .map(|i| {
                let d = (bx - base.icons[i].cx()).abs() / (s + GAP);
                let f = if d < spread { 0.5 * (1.0 + (std::f32::consts::PI * d / spread).cos()) } else { 0.0 };
                1.0 + (mag - 1.0) * f
            })
            .collect()
    }

    fn animate(&mut self, ctx: &mut Ctx) {
        let now = Instant::now();
        let dt = (now - self.last_frame).as_secs_f32().min(0.05);
        self.last_frame = now;
        let target = self.target_zoom();
        let k = 1.0 - (-dt * 18.0).exp();
        let mut moving = false;
        for (z, t) in self.zoom.iter_mut().zip(target.iter()) {
            if (*z - *t).abs() < 0.003 {
                *z = *t;
            } else {
                *z += (*t - *z) * k;
                moving = true;
            }
        }
        if !moving && self.mouse.is_none() {
            self.animating = false;
            unsafe {
                let _ = KillTimer(Some(self.hwnd), TIMER_ANIM);
            }
            self.update_region();
        }
        self.render(ctx);
    }

    fn scan_tick(&mut self, ctx: &mut Ctx) {
        if self.cfg.hide_taskbar {
            self.enforce_taskbar_hidden();
        }
        let before = self.fs_hidden;
        self.check_fullscreen();
        // pick up a new icons folder content
        let mtime = std::fs::metadata(&self.icons_dir).and_then(|m| m.modified()).ok();
        if mtime != self.icons_mtime {
            self.icons.clear();
            self.refresh_overrides();
        }
        let changed = self.rescan(false);
        let fg = unsafe { GetForegroundWindow() };
        let fg_changed = fg != self.fg;
        if fg_changed {
            self.fg = fg;
            if !self.fs_hidden {
                unsafe {
                    let _ = SetWindowPos(self.hwnd, Some(HWND_TOPMOST), 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
                }
            }
        }
        if changed {
            self.win_px = (0, 0, 0, 0);
            self.place();
        } else {
            // monitor geometry / DPI can change without a message reaching us
            self.place();
        }
        if (changed || fg_changed || before != self.fs_hidden || mtime != self.icons_mtime) && !self.fs_hidden {
            self.render(ctx);
        }
    }

    // -- drawing ------------------------------------------------------------------

    pub fn render(&mut self, ctx: &mut Ctx) {
        if self.fs_hidden || self.win_px.2 <= 1 {
            return;
        }
        // load icons before drawing starts
        let items = self.items.clone();
        let imgs: Vec<Option<ImageData>> = items.iter().map(|it| self.icon_for(it)).collect();
        let (dc, off) = match self.host.begin_draw() {
            Ok(v) => v,
            Err(e) => {
                crate::log!("dock: BeginDraw failed: {e}");
                self.lost = true;
                return;
            }
        };
        let geo = self.geometry(&self.zoom);
        let hover = self.mouse.and_then(|(x, y)| self.hit(x, y));
        let fg = self.fg;
        let accent = palette::TEXT;
        {
            let mut p = Painter::new(dc, ctx.gfx, ctx.res, self.scale, off.x as f32, off.y as f32);
            p.clear();
            if !items.is_empty() {
                let plate = geo.plate;
                let c = &self.cfg;
                if let Some(g) = dock_path(&p, plate, c.corner_radius, c.ear) {
                    // soft shadow around the sides and top; it extends below the screen edge
                    p.shadow(Rect::new(plate.x, plate.y, plate.w, plate.h + 60.0), c.corner_radius, 0.45);
                    p.fill_geometry(&g, Color::black(c.opacity));
                }
                // separator between pinned and other apps
                if let Some(i) = self.sep {
                    if let Some(r) = geo.icons.get(i) {
                        let x = r.right() + GAP * 0.5 + SEP_W * 0.5;
                        p.line(x, plate.y + PAD_Y, x, plate.bottom() - PAD_Y, 1.2, Color::white(0.22));
                    }
                }
                for (i, it) in items.iter().enumerate() {
                    let r = geo.icons[i];
                    match (&imgs[i], it.kind) {
                        (Some(img), _) => p.image(img, r, 0.0, 1.0),
                        (None, Kind::Start) => draw_start(&mut p, r),
                        (None, Kind::App) => {
                            p.fill_rounded(r, r.w * 0.24, Color::white(0.14));
                            let ch: String = it.name.chars().next().map(|c| c.to_uppercase().collect()).unwrap_or_default();
                            p.text(&ch, r, &TextStyle::new(r.w * 0.5, palette::TEXT).semibold().center());
                        }
                    }
                    if !it.windows.is_empty() {
                        let active = it.windows.iter().any(|&v| SendHwnd(v).hwnd() == fg);
                        let col = if active { accent } else { Color::white(0.55) };
                        p.fill_circle(r.cx(), plate.bottom() - 4.5, if active { 2.2 } else { 1.8 }, col);
                    }
                }
                if let Some(i) = hover {
                    let r = geo.icons[i];
                    let st = TextStyle::new(12.0, palette::TEXT).medium().center();
                    let (tw, _) = p.measure(&items[i].name, &st);
                    let w = tw + 22.0;
                    let x = (r.cx() - w * 0.5).clamp(4.0, (self.win_w - w - 4.0).max(4.0));
                    let lr = Rect::new(x, (r.y - 34.0).max(2.0), w, 24.0);
                    p.fill_rounded(lr, 9.0, Color::black(0.86));
                    p.stroke_rounded(lr.inset(0.5), 9.0, 1.0, Color::white(0.12));
                    p.text(&items[i].name, lr, &st);
                }
            }
        }
        if let Err(e) = self.host.end_draw() {
            crate::log!("dock: EndDraw failed: {e}");
            self.lost = true;
        }
        ctx.res.end_frame();
    }
}

// ---------------------------------------------------------------------------
// Drawing helpers
// ---------------------------------------------------------------------------

/// Dock plate: rounded top corners, concave "ears" where the sides meet the
/// bottom edge of the screen (the notch's shape, flipped upside down).
fn dock_path(p: &Painter, body: Rect, top_radius: f32, ear: f32) -> Option<windows::Win32::Graphics::Direct2D::ID2D1Geometry> {
    let (x0, x1) = (body.x, body.right());
    let (top, bottom) = (body.y, body.bottom());
    let h = body.h.max(1.0);
    let e = ear.min(h * 0.5).max(0.0);
    let r = top_radius.min(body.w * 0.5).min(h - e).max(0.0);
    p.path(|b| {
        b.move_to(x0 - e, bottom);
        if e > 0.0 {
            b.arc_to(x0, bottom - e, e, false);
        }
        b.line_to(x0, top + r);
        if r > 0.0 {
            b.arc_to(x0 + r, top, r, true);
        }
        b.line_to(x1 - r, top);
        if r > 0.0 {
            b.arc_to(x1, top + r, r, true);
        }
        b.line_to(x1, bottom - e);
        if e > 0.0 {
            b.arc_to(x1 + e, bottom, e, false);
        }
        b.close();
    })
}

/// The Windows logo: four rounded squares.
fn draw_start(p: &mut Painter, r: Rect) {
    let s = r.w * 0.56;
    let gap = s * 0.09;
    let sq = (s - gap) * 0.5;
    let (x, y) = (r.cx() - s * 0.5, r.cy() - s * 0.5);
    let c = Color::hex(0x4CC2FF);
    for (dx, dy) in [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)] {
        p.fill_rounded(Rect::new(x + dx * (sq + gap), y + dy * (sq + gap), sq, sq), sq * 0.14, c);
    }
}

fn focus(h: HWND) {
    unsafe {
        if IsIconic(h).as_bool() {
            let _ = ShowWindow(h, SW_RESTORE);
        }
        let _ = SetForegroundWindow(h);
    }
}

// ---------------------------------------------------------------------------
// System queries
// ---------------------------------------------------------------------------

fn stem_of(path: &str) -> String {
    Path::new(path).file_stem().and_then(|s| s.to_str()).unwrap_or(path).to_string()
}

fn same_path(a: &str, b: &str) -> bool {
    a.replace('/', "\\").eq_ignore_ascii_case(&b.replace('/', "\\"))
}

/// Visible top-level windows that would appear on a taskbar, with the
/// executable that owns them.
fn running_windows() -> Vec<(isize, String)> {
    let mut found: Vec<HWND> = Vec::new();
    unsafe {
        let _ = EnumWindows(Some(enum_cb), LPARAM(&mut found as *mut Vec<HWND> as isize));
    }
    let me = std::process::id();
    found
        .into_iter()
        .filter_map(|h| {
            let mut pid = 0u32;
            unsafe { GetWindowThreadProcessId(h, Some(&mut pid)) };
            if pid == 0 || pid == me {
                return None;
            }
            exe_of(pid).map(|exe| (h.0 as isize, exe))
        })
        .collect()
}

unsafe extern "system" fn enum_cb(hwnd: HWND, lp: LPARAM) -> BOOL {
    let out = &mut *(lp.0 as *mut Vec<HWND>);
    if wanted(hwnd) {
        out.push(hwnd);
    }
    BOOL(1)
}

unsafe fn wanted(hwnd: HWND) -> bool {
    if !IsWindowVisible(hwnd).as_bool() || GetWindowTextLengthW(hwnd) == 0 {
        return false;
    }
    if GetWindow(hwnd, GW_OWNER).is_ok_and(|o| !o.is_invalid()) {
        return false;
    }
    let ex = GetWindowLongW(hwnd, GWL_EXSTYLE) as u32;
    if ex & WS_EX_TOOLWINDOW.0 != 0 && ex & WS_EX_APPWINDOW.0 == 0 {
        return false;
    }
    let mut cloaked = 0u32;
    let _ = DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, &mut cloaked as *mut u32 as *mut c_void, 4);
    if cloaked != 0 {
        return false;
    }
    let mut buf = [0u16; 64];
    let n = GetClassNameW(hwnd, &mut buf).max(0) as usize;
    let class = String::from_utf16_lossy(&buf[..n]);
    !matches!(class.as_str(), "Progman" | "WorkerW" | "Shell_TrayWnd" | "Shell_SecondaryTrayWnd")
}

fn exe_of(pid: u32) -> Option<String> {
    unsafe {
        let h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid).ok()?;
        let mut buf = [0u16; 520];
        let mut len = buf.len() as u32;
        let ok = QueryFullProcessImageNameW(h, PROCESS_NAME_FORMAT(0), PWSTR(buf.as_mut_ptr()), &mut len);
        let _ = CloseHandle(h);
        ok.ok()?;
        Some(String::from_utf16_lossy(&buf[..len as usize]))
    }
}

/// The icon Windows shows for a file, at up to `px` pixels.
unsafe fn shell_icon(path: &str, px: i32) -> Option<ImageData> {
    let wpath = HSTRING::from(path);
    let factory: IShellItemImageFactory = SHCreateItemFromParsingName(&wpath, None).ok()?;
    let hbmp = factory.GetImage(SIZE { cx: px, cy: px }, SIIGBF_ICONONLY | SIIGBF_BIGGERSIZEOK).ok()?;
    let img = hbitmap_to_image(hbmp);
    let _ = DeleteObject(hbmp.into());
    img
}

unsafe fn hbitmap_to_image(h: HBITMAP) -> Option<ImageData> {
    let mut bm = BITMAP::default();
    if GetObjectW(h.into(), std::mem::size_of::<BITMAP>() as i32, Some(&mut bm as *mut BITMAP as *mut c_void)) == 0 {
        return None;
    }
    let (w, hh) = (bm.bmWidth, bm.bmHeight);
    if w <= 0 || hh <= 0 {
        return None;
    }
    let mut bi = BITMAPINFO::default();
    bi.bmiHeader = BITMAPINFOHEADER {
        biSize: std::mem::size_of::<BITMAPINFOHEADER>() as u32,
        biWidth: w,
        biHeight: -hh, // top-down
        biPlanes: 1,
        biBitCount: 32,
        biCompression: 0,
        ..Default::default()
    };
    let mut px = vec![0u8; (w * hh * 4) as usize];
    let dc = GetDC(None);
    let lines = GetDIBits(dc, h, 0, hh as u32, Some(px.as_mut_ptr() as *mut c_void), &mut bi, DIB_RGB_COLORS);
    ReleaseDC(None, dc);
    if lines == 0 {
        return None;
    }
    // icons without an alpha channel come back fully transparent
    if px.chunks_exact(4).all(|c| c[3] == 0) {
        for c in px.chunks_exact_mut(4) {
            c[3] = 255;
        }
    }
    Some(ImageData::from_pbgra(w as u32, hh as u32, px))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn paths() {
        assert!(same_path("C:/Windows/explorer.exe", "c:\\windows\\Explorer.EXE"));
        assert_eq!(stem_of("C:\\Program Files\\App\\app.exe"), "app");
    }
}
