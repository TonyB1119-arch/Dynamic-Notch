//! Battery + charging state. Purely event driven: Windows sends
//! WM_POWERBROADCAST when the power source or percentage changes.

use windows::Win32::System::Power::{GetSystemPowerStatus, SYSTEM_POWER_STATUS};

use super::{Cx, Indicator, Module, ModuleId, Peek, SystemEvent, Trailing};
use crate::gfx::Icon;
use crate::util::{palette, Color};

const ID: ModuleId = "battery";

#[derive(Clone, Copy, PartialEq, Debug, Default)]
struct State {
    has_battery: bool,
    plugged: bool,
    percent: u8,
    saver: bool,
    /// Minutes of charge left on battery (rounded to 5), 0 when Windows can't tell.
    mins: u32,
}

fn read() -> State {
    let mut s = SYSTEM_POWER_STATUS::default();
    if unsafe { GetSystemPowerStatus(&mut s) }.is_err() {
        return State::default();
    }
    State {
        has_battery: s.BatteryFlag != 128 && s.BatteryFlag != 255 && s.BatteryLifePercent <= 100,
        plugged: s.ACLineStatus == 1,
        percent: s.BatteryLifePercent.min(100),
        saver: s.SystemStatusFlag == 1,
        mins: if s.BatteryLifeTime == u32::MAX { 0 } else { (s.BatteryLifeTime / 60 + 2) / 5 * 5 },
    }
}

pub struct Battery {
    state: State,
    warned_low: bool,
    warned_full: bool,
}

impl Battery {
    pub fn new() -> Self {
        Self { state: State::default(), warned_low: false, warned_full: false }
    }

    fn level(&self) -> f32 {
        self.state.percent as f32 / 100.0
    }

    /// Shown next to the percentage: an infinity sign while plugged in,
    /// otherwise the time left on battery (when Windows has an estimate).
    fn extra(&self) -> Option<String> {
        if self.state.plugged {
            Some("\u{221E}".to_string())
        } else if self.state.mins > 0 {
            let (h, m) = (self.state.mins / 60, self.state.mins % 60);
            Some(if h > 0 { format!("{h}h {m:02}m") } else { format!("{m}m") })
        } else {
            None
        }
    }
}

impl Module for Battery {
    fn id(&self) -> ModuleId {
        ID
    }
    fn title(&self) -> &str {
        "Battery"
    }
    fn icon(&self) -> Icon {
        Icon::Bolt
    }

    fn start(&mut self, _cx: &mut Cx) {
        self.state = read();
    }

    fn on_system(&mut self, ev: &SystemEvent, cx: &mut Cx) {
        if !matches!(ev, SystemEvent::PowerChanged) {
            return;
        }
        let new = read();
        let old = self.state;
        self.state = new;
        if !new.has_battery || new == old {
            return;
        }
        cx.fx.redraw = true;
        let level = self.level();
        let pct = format!("{}%", new.percent);
        let hud = |color: Color, text: String, ms: u64| {
            Peek::new(Icon::Bolt, color, "", "")
                .trailing(Trailing::Level { frac: level, color, text: Some(text) })
                .key("battery")
                .duration_ms(ms)
        };
        if new.plugged && !old.plugged && cx.cfg.battery.peek_on_plug {
            let text = if new.percent >= 100 { "Fully charged".to_string() } else { format!("Charging · {pct}") };
            cx.fx.peek(hud(palette::GREEN, text, 2600));
            self.warned_low = false;
        } else if !new.plugged && old.plugged && cx.cfg.battery.peek_on_plug {
            cx.fx.peek(hud(Color::white(0.92), format!("On battery · {pct}"), 2000));
        }
        let low = cx.cfg.battery.low_threshold;
        if !new.plugged && new.percent <= low && !self.warned_low {
            self.warned_low = true;
            cx.fx.peek(hud(palette::RED, format!("Low battery · {pct}"), 5000));
        }
        if new.plugged && new.percent >= 100 && old.percent < 100 && !self.warned_full {
            self.warned_full = true;
            cx.fx.peek(hud(palette::GREEN, "Fully charged".to_string(), 2600));
        }
        if new.percent < 95 {
            self.warned_full = false;
        }
    }

    fn indicators(&self, out: &mut Vec<Indicator>) {
        if self.state.has_battery {
            out.push(Indicator {
                color: if self.state.saver { palette::YELLOW } else { Color::white(0.9) },
                icon: None,
                label: self.extra(),
                battery: Some((self.level(), self.state.plugged)),
                dot: false,
            });
        }
    }
}
